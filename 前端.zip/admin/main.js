import App from './App'
import { myRequest } from './util/api.js'

// 使用element
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';

// 引入加密
import { encryptDes, decryptDes  } from './util/des.js' // 引用路径根据自己的文件结构而定

// 二次封装  ajax
Vue.prototype.$myRequest = myRequest;
//加密解密/
Vue.prototype.$encryptDes = encryptDes;
Vue.prototype.$decryptDes = decryptDes;

Vue.use(ElementUI)
// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif