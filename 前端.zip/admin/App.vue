<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	.All_title{
		width: 100%;
		height: 120upx;
		/* background-color: #0000FF; */
		font-size: 50upx;
		font-weight: 550;
	}
</style>
