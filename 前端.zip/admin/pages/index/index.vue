<template>
	<view class="content">
		
		<etop :adminUse="adminUse"></etop>
		<eleft v-on:childMenuSwitch="childMenuSwitch"></eleft>
		<ebody :pages="pages" :adminUse="adminUse"></ebody>

	</view>
</template>

<script>
	import etop from 'components/e_top'
	import eleft from 'components/e_left'
	import ebody from '../../components/e_body.vue'
	export default {
		data() {
			return {
				pages: '',
				adminUse : {
					adminId : '',
					adminKey : ''
				}
			}
		},
		components: {
			etop,
			eleft,
			ebody
		},
		onLoad(options) {
			// console.log(options.data)
			if (options.data === undefined) {
				uni.redirectTo({
				    url: '../login/login'
				});
			} else {
				let obj = JSON.parse(options.data);
				this.adminUse.adminId = obj.userid
				this.adminUse.adminKey = obj.userkey
			}
		},
		methods: {
			childMenuSwitch(value) {
				// console.log(value,'这是传回来的值')
				this.pages = value
			},
			
		}
	}
</script>

<style>

</style>
