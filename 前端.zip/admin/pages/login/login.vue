<template>
	<view class="content_all">
		<view class="content_1 content">
			<view class="header">
				hello !
			</view>
			<view style="margin-top: 20upx;font-size: 25px;">欢迎来到后台管理 ！</view>
			<view class="list">
				<view class="list-call">
					<image class="img" src="/static/shilu-login/phone.png"></image>
					<input class="biaoti" v-model="userid" type="text" maxlength="11" placeholder="输入管理员账号" />
				</view>
				<view class="list-call" style="margin-top: 20upx;">
					<image class="img" src="/static/shilu-login/block.png"></image>
					<input class="biaoti" v-model="userkey" type="text" maxlength="32" placeholder="输入管理员密码"
						password="true" />
				</view>
			</view>


			<view class="dlbutton" hover-class="dlbutton-hover" @click="login()">
				<text>登录</text>
			</view>
			<el-checkbox v-model="radio" style="margin-top: 30upx;font-size: 20upx;color: #82848A;">七天免登录</el-checkbox>


		</view>

		<image
			src="http://cd7.yesapi.net/0B4163C86181759DD5DE6C761AF719A5_20200629155530_4fdd81610bea6fdaabbe27637f116be6.png"
			mode="aspectFill" style="width: 100%;height: 100%;"></image>


		<loading ref="loading" :custom="false" :shadeClick="false" :type="1" @callback="callback()">
			<!-- <view class="test">自定义</view> -->
		</loading>

	</view>
</template>

<script>
	import loading from '../../components/xuan-loading/xuan-loading.vue'
	export default {

		data() {
			return {
				userid: '',
				userkey: '',
				radio: false
				// people: []
			};
		},
		onShow() {
			const value = uni.getStorageSync('ZXCW_ADMIN');
			if (value) {
				// 
				let adminAllData = JSON.parse(this.$decryptDes(value))
				// console.log(JSON.parse(this.$decryptDes(value)))
				let time0 = new Date().getTime() //获取当前毫秒数
				let h = ((time0 - adminAllData.nowTime) / 100 / 60 / 60) / 24
				if (h < 7) {
					// console.log('还可以继续登录')
					uni.redirectTo({
						url: `../index/index?data=${JSON.stringify(adminAllData)}`
					})
				} else {
					// 清除登录信息
					uni.removeStorageSync('ZXCW_ADMIN');
				}
				// uni.removeStorageSync('ZXCW_ADMIN');
			}
		},
		components: {
			loading
		},
		methods: {
			login() {
				if (this.userid === '') {
					uni.showToast({
						title: "请先填写账号",
						icon: 'error'
					})
					return
				}
				if (this.userkey === '') {
					uni.showToast({
						title: "请先填写密码",
						icon: 'error'
					})
					return
				}
				this.$refs.loading.open();
				this.userkey = this.$encryptDes(this.userkey)
				this.$myRequest({
					url: '/adminLogin',
					data: {
						userid: this.userid,
						userkey: this.userkey
					}
				}).then(res => {
					console.log(res.status)
					if (this.radio === true) {
						let nowTime = new Date().getTime() //获取时间戳
						let adminData = {
							userid: this.userid,
							userkey: this.userkey,
							nowTime: nowTime
						}
						adminData = JSON.stringify(adminData);
						// newCookey = this.$encryptDes(newCookey)
						let admin = this.$encryptDes(adminData)
						uni.setStorageSync('ZXCW_ADMIN', admin); //保存密码信息成功
					} else {
						uni.removeStorageSync('ZXCW_ADMIN');
					}
					if (res.status === 1) {
						console.log('登陆成功')

						uni.redirectTo({
							url: `../index/index?data=${JSON.stringify({userid: this.userid,userkey: this.userkey})}`
							
						})
						this.$refs.loading.close();
					} else {
						this.$refs.loading.close();
						uni.showToast({
							title: '请输入正确的账号密码',
							icon: 'error'
						})

					}
				})
			}
		}
	}
</script>

<style>
	.content_all {
		display: flex;
		justify-content: center;
		flex-direction: row;
		align-items: center;
		height: 100vh;
		width: 100%;

	}

	.content_1 {
		width: 50%;
		height: 50%;
		margin-left: 100upx;

	}

	.content {
		display: flex;
		flex-direction: column;
		/* justify-content:center; */
		/* align-items: center; */


	}

	.header {
		font-size: 50px;
	}


	.list {
		display: flex;
		flex-direction: column;
		padding-top: 40upx;
		/* padding-left: 70upx;
		padding-right: 70upx; */
	}

	.list-call {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		height: 20upx;
		color: #333333;
		width: 500upx;
		margin-bottom: 3upx;

		padding: 20upx;
		background-color: #F6F4FC;

	}

	.list-call .img {
		width: 20upx;
		height: 20upx;
	}

	.list-call .biaoti {
		flex: 1;
		text-align: left;
		font-size: 12px;
		line-height: 100upx;
		margin-left: 16upx;
	}

	.dlbutton {
		color: #FFFFFF;
		font-size: 12upx;
		width: 200upx;
		height: 55upx;
		background-color: #1890FF;

		align-items: center;
		display: flex;
		justify-content: center;

		line-height: 100upx;
		text-align: center;
		/* margin-left: auto;
		margin-right: auto; */
		margin-top: 30upx;
	}

	.dlbutton hover {
		background-color: #1890cc;
	}

	.xieyi {
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: center;
		font-size: 22upx;
		margin-top: 80upx;
		color: #FFA800;
		text-align: center;
		height: 40upx;
		line-height: 40upx;
	}

	.xieyi text {
		font-size: 22upx;
		margin-left: 15upx;
		margin-right: 15upx;
	}
</style>
