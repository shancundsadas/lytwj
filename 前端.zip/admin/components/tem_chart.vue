<template>
	<view>
		<!-- <canvas canvas-id="canvasLineA" id="canvasLineA" class="charts" @touchmove="moveLineA" @touchend="moveLineA"></canvas> -->

		<!-- <view slot="top" style="height: 620upx;"></view> -->
		<view class="charts-box" v-if="showChart">
			<qiun-data-charts type="line" :chartData="chartData" background="none" :ontouch="true" :opts="line" />
		</view>

		<!-- 画布，图表的HTML部分-->
		<view class="C_bg">
			<view class="C_bg_item">
				测量日期
			</view>
			<view class="C_bg_item" style="border-left: 1px solid #9e9e9e;border-right: 1px solid #9e9e9e;">
				摄氏度(℃)
			</view>
			<view class="C_bg_item">
				华氏度(℉)
			</view>
		</view>
		<view class="C_list">
			<view class="list_item" v-for="item in listData">
				<view class="C_bg_list_item" style="flex-direction: column">
					<P>{{ item.time | time0 }}</P>
					<p>{{ item.time | time1 }}</p>
				</view>
				<view class="C_bg_list_item">
					{{ item.temperature }}
				</view>
				<view class="C_bg_list_item">
					{{ item.temperature | C_F }}
				</view>
			</view>
		</view>
		<el-pagination layout="prev, pager, next" :total="allPage" :current-page.sync="nowPage"
			@current-change="current_change">
		</el-pagination>
	</view>
</template>

<script>
	import uCharts from '../util/u-charts.js.js'; //引入js文件
	var _self; //用于全局使用this
	var canvaLineA = null; //uCharts实例

	export default {
		props:['searchData'],
		data() {
			return {
				allPage: 0,
				nowPage: 1,
				showChart: false,
				chartData: {
					categories: [], //横轴
					series: [{
						name: "温度",
						data: [] //纵轴
					}, ]
				},
				line: {
					"type": "line",
					"canvasId": "",
					"canvas2d": false,
					"background": "none",
					"animation": true,
					"timing": "easeOut",
					"duration": 1000,
					"color": [
						"#91CB74",
						"#FAC858",
						"#EE6666",
						"#73C0DE",
						"#3CA272",
						"#FC8452",
						"#9A60B4",
						"#ea7ccc"
					],
					"padding": [
						15,
						10,
						0,
						15
					],
					"rotate": false,
					"errorReload": true,
					"fontSize": 13,
					"fontColor": "#666666",
					"enableScroll": true,
					"touchMoveLimit": 60,
					"enableMarkLine": false,
					"dataLabel": true,
					"dataPointShape": true,
					"dataPointShapeType": "solid",
					"tapLegend": true,
					"xAxis": {
						"disabled": false,
						"axisLine": true,
						"axisLineColor": "#CCCCCC",
						"calibration": true,
						"fontColor": "#666666",
						"fontSize": 13,
						"rotateLabel": true,
						"itemCount": 5,
						"boundaryGap": "center",
						"disableGrid": true,
						"gridColor": "#CCCCCC",
						"gridType": "solid",
						"dashLength": 4,
						"gridEval": 1,
						"scrollShow": false,
						"scrollAlign": "left",
						"scrollColor": "#A6A6A6",
						"scrollBackgroundColor": "#EFEBEF",
						"format": "yAxisDemo0"
					},
					"yAxis": {
						"disabled": false,
						"disableGrid": false,
						"splitNumber": 4,
						"gridType": "dash",
						"dashLength": 2,
						"gridColor": "#CCCCCC",
						"padding": 10,
						"showTitle": false,
						"data": []
					},
					"legend": {
						"show": true,
						"position": "bottom",
						"float": "center",
						"padding": 5,
						"margin": 5,
						"backgroundColor": "rgba(0,0,0,0)",
						"borderColor": "rgba(0,0,0,0)",
						"borderWidth": 0,
						"fontSize": 13,
						"fontColor": "#666666",
						"lineHeight": 11,
						"hiddenColor": "#CECECE",
						"itemGap": 10
					},
					"extra": {
						"line": {
							"type": "curve",
							"width": 2
						},
						"tooltip": {
							"showBox": true,
							"showArrow": true,
							"showCategory": false,
							"borderWidth": 0,
							"borderRadius": 0,
							"borderColor": "#000000",
							"borderOpacity": 0.7,
							"bgColor": "#000000",
							"bgOpacity": 0.7,
							"gridType": "solid",
							"dashLength": 4,
							"gridColor": "#CCCCCC",
							"fontColor": "#FFFFFF",
							"splitLine": true,
							"horizentalLine": false,
							"xAxisLabel": false,
							"yAxisLabel": false,
							"labelBgColor": "#FFFFFF",
							"labelBgOpacity": 0.7,
							"labelFontColor": "#666666"
						},
						"markLine": {
							"type": "solid",
							"dashLength": 4,
							"data": []
						}
					}
				},

				listData: []
			}
		},
		onLoad() {

		},
		mounted() {
			this.getOneTemData()
			console.log('加载了几次')
		},
		watch: {
			nowPage(value) {
				console.log('切换页面')
				this.getOneTemData()
			},
		},
		filters: {
			time0(value) {
				let time = new Date(parseInt(value) * 1000)
				return time.getHours() + ':' + time.getMinutes()
			},
			time1(value) {
				let time = new Date(parseInt(value) * 1000)
				return time.getFullYear() + '/' + (time.getMonth() + 1) + '/' + time.getDay()
				// return time.getTime()
			},
			C_F(value) {
				return (value * 9 / 5 + 32).toFixed(2)
			}
		},
		methods: {
			current_change(currentPage) { //改变当前页
				this.showChart = false
				this.nowPage = currentPage
				console.log('当前页', currentPage)
			},
			// 显示
			showChartTool() {
				this.listData.forEach((r, i) => {
					// console.log('数据r',r,'第几个',i)
					this.chartData.categories[i] = r.time
					this.chartData.series[0].data[i] = r.temperature
				})
				this.$forceUpdate()
				this.showChart = true
			},

			getOneTemData() {
				const myWd = this.$myRequest({
					url: '/getOneTemperature',
					method: 'post',
					data: {
						userid: this.searchData.adminId,
						userkey: this.searchData.adminKey,
						getuser: this.searchData.userId,
						page : this.nowPage
					}
				})

				myWd.then(res => {
					console.log(res.result.res.last_page)
					this.listData = res.result.res.data
					this.allPage = res.result.res.last_page * 10
					console.log(this.allPage)
				}).then(r => {
					setTimeout(r => {
						this.showChartTool()
					}, 500)
				})
			},
		}
	}
</script>

<style>
	.charts {
		width: 750upx;
		height: 500upx;
		background-color: #FFFFFF;
	}

	.C_bg {
		width: 100%;
		height: 95upx;
		border-bottom: 1px solid #9e9e9e;
		margin-top: 20upx;
		display: flex;
		align-items: center;
	}

	.C_bg_item {
		width: 250upx;
		height: 60%;
		/* background-color: #006FA7; */
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 28upx;
		font-weight: 700;
	}

	.list_item {
		width: 100%;
		height: 90upx;
		border-bottom: 1px solid #dedede;
		display: flex;
		align-items: center;
	}

	.C_bg_list_item {
		width: 250upx;
		height: 60%;
		/* background-color: #006FA7; */
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 28upx;
		font-size: 700;
	}
</style>
