<template>
    <div id="comm" style="width: 100%;">
		<!-- 这里显示所有的页面 -->
        <el-col :span="21" style="margin-top: 1rem">
         <el-row :gutter="30" class="row-bg" type="flex" align="top" style="margin: 1.5% 1.5% 1.5% 1.5% ; width: 100%;">
                <el-col :span="6" style="width: 100%;">
					<!-- 添加界面 -->
                    <userData v-show="show[0]" :adminUse = "adminUse"></userData>
					<userTem v-show="show[1]" :adminUse = "adminUse"></userTem>
					<adminQx v-show="show[2]" :adminUse = "adminUse"></adminQx>
					
                </el-col>
            </el-row>
        </el-col>
    </div>
</template>
<script>
import userData from './user_data.vue'
import userTem from './user_tem.vue'
import adminQx from './admin_qx.vue'
export default {
	data() {
		return {
			// 每个界面对应一个
			show : [true,false,false]
		}
	},
	// 接收点击的数据
	props:['pages','adminUse'],
	mounted() {
		console.log(this.pages)
	},
    components:{
        userData,
		userTem,
		adminQx
    },
	watch:{
		pages(value,old){
			this.show.forEach( (r,i) => {
				this.show[i] = false
			})
			// 新的页面作为判断
			if(value === 'comm1'){
				this.show[0] = true
			}else if(value === 'comm2'){
				this.show[1] = true
				console.log(this.show[1])
			}else if(value === 'comm3'){
				this.show[2] = true
				console.log(this.show[2])
			}
			this.$forceUpdate()
		}
	}
}
</script>
