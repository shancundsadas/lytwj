<template>
	<div id='HeaderMenu'>
		<!-- <el-row class='tac'> -->
		<el-col :span='2'>
			<el-menu background-color='#ffffff' text-color='#303133' active-text-color="#409EFF" default-active="1" style="width: 300upx;">
				<el-menu-item index="1" style="font-size: large;" v-on:click="notifyParentCom('comm1')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 用户管理	</span>
				</el-menu-item>
				<el-menu-item index="2" style="font-size: large;" v-on:click="notifyParentCom('comm2')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 体温检测</span>
				</el-menu-item>
				<el-menu-item index="3" style="font-size: large;" v-on:click="notifyParentCom('comm3')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 权限分配</span>
				</el-menu-item>
			<!-- 	<el-menu-item index="4" style="font-size: large;" v-on:click="notifyParentCom('comm4')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航四</span>
				</el-menu-item>
				<el-menu-item index="5" style="font-size: large;" v-on:click="notifyParentCom('comm5')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航五</span>
				</el-menu-item>
				<el-menu-item index="6" style="font-size: large;" v-on:click="notifyParentCom('comm6')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航六</span>
				</el-menu-item>
				<el-menu-item index="7" style="font-size: large;" v-on:click="notifyParentCom('comm7')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航七</span>
				</el-menu-item>
				<el-menu-item index="8" style="font-size: large;" v-on:click="notifyParentCom('comm8')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航八</span>
				</el-menu-item>
				<el-menu-item index="9" style="font-size: large;" v-on:click="notifyParentCom('comm9')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航九</span>
				</el-menu-item>
				<el-menu-item index="10" style="font-size: large;" v-on:click="notifyParentCom('comm10')">
					<i class='el-icon-menu'></i>
					<span slot="title"> 导航十</span>
				</el-menu-item> -->
			</el-menu>
		</el-col>
		<!-- </el-row> -->
	</div>

</template>
<script>
	export default {
		data() {
			return {

			}
		},
		components:{
			
		},
		methods: {
			notifyParentCom(target) {
				console.log(target);
				switch (target) {
					case 'comm1':
						this.$emit('childMenuSwitch', 'comm1')
						break;
					case 'comm2':
						this.$emit('childMenuSwitch', 'comm2')
						break;
					case 'comm3':
						this.$emit('childMenuSwitch', 'comm3')
						break;
					case 'comm4':
						this.$emit('childMenuSwitch', 'comm4')
						break;
					case 'comm5':
						this.$emit('childMenuSwitch', 'comm5')
						break;
					case 'comm6':
						this.$emit('childMenuSwitch', 'comm6')
						break;
					case 'comm7':
						this.$emit('childMenuSwitch', 'comm7')
						break;
					case 'comm8':
						this.$emit('childMenuSwitch', 'comm8')
						break;
					case 'comm9':
						this.$emit('childMenuSwitch', 'comm9')
						break;
					case 'comm10':
						this.$emit('childMenuSwitch', 'comm10')
						break;
				}
			}
		}
	}
</script>
<style>

</style>
