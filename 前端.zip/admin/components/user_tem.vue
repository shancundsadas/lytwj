<template>
	<view>
		<view class="All_title">
			今日测温信息
		</view>
		<view class="user_data_but">
			<!-- <el-button type="primary" @click="url = '/getAllUser'">查看全部</el-button>
			<el-button type="primary">主要按钮</el-button>
			<el-button type="primary">查看今日未测温</el-button> -->
			<el-button type="primary" @click="seeTemNote">查看今日体温异常</el-button>
			<el-button type="primary" @click="seeAllData">{{ buttonView }}</el-button>
		</view>
		<view class="data_table">
			<el-table :data="tableData" border style="width:100%">
				<el-table-column fixed prop="user_id" label="用户ID" width="150">
				</el-table-column>
				<el-table-column prop="name" label="姓名" width="120">
				</el-table-column>
				<el-table-column prop="adress" label="地址" width="300">
				</el-table-column>
				<el-table-column prop="time" label="时间" width="120">
				</el-table-column>
				<el-table-column prop="temperature" label="体温" width="120">
				</el-table-column>
			</el-table>
			<el-pagination background layout="prev, pager, next" :total="allPage" :current-page.sync="currentPage"
				@current-change="current_change" style="text-align: center;margin-top: 100upx;">
			</el-pagination>
		</view>

		

	</view>
</template>

<script>
	export default {
		name: "user_data",
		props:['adminUse'],
		data() {
			return {
				total: '',
				currentPage: 1, //当前页
				tableData: [],
				allPage: 0,
				getUser : {},
				url : '',
				adminId : '',
				adminKey : '',
				nowButton : 0 ,//0表示搜索今日 1表示 搜索全部  2表示搜索体温过高
				buttonView : '查看全部体温信息'
			};
		},
		
		filters:{
			time0(value){
				return value
			}
		},
		mounted() {
			this.adminId = this.adminUse.adminId
			this.adminKey = this.adminUse.adminKey
			this.getToday() 	
		},
		watch: {
			currentPage(value) {
				// console.log('切换页面')
				if(this.nowButton === 0){
					this.getToday()
				}else if(this.nowButton === 1){
					this.getAll()
				}else if(this.nowButton === 2){
					this.getTodayNote()
				}
			},
		},
		
		methods: {
			current_change(currentPage) { //改变当前页
				this.currentPage = currentPage
				// console.log('当前页', currentPage)
			},
			// 查询今日体温异常
			seeTemNote(){
				this.getTodayNote()
			},
			// 查看全部体温表
			seeAllData(){
				if(this.nowButton === 0){
					this.currentPage = 1
					this.getAll()
					this.nowButton = 1
					this.buttonView = '查看今日体温信息'
				}else if(this.nowButton === 1){
					this.currentPage = 1
					this.getToday()
					this.nowButton = 0
					this.buttonView = '查看全部体温信息'
				}
				
			},
			getToday() {
				// 获取今日
				this.$myRequest({
					url: '/getAllTemperatureToday',
					data: {
						userid: this.adminId,
						userkey: this.adminKey,
						page: this.currentPage
					}
				}).then(res => {
					this.allPage = res.result.res.last_page * 10
					this.tableData = res.result.res.data
					this.tableData.forEach( (r,i) => {
						// console.log(r.time)
						let time0 = new Date(r.time * 1000).getHours() + ':' + new Date(r.time * 1000).getMinutes()
						// console.log(r.time1 + ' ' +  time0)
						r.time = r.time1 + ' ' +  time0
					})
					this.$forceUpdate()
				})
			},
			
			getTodayNote() {
				// 获取今日
				this.$myRequest({
					url: '/getTemNo',
					data: {
						userid: this.adminId,
						userkey: this.adminKey,
						page: this.currentPage
					}
				}).then(res => {
					// console.log(res.result.res)
					this.allPage = res.result.res.last_page * 10
					this.tableData = res.result.res.data
					this.tableData.forEach( (r,i) => {
						// console.log(r.time)
						let time0 = new Date(r.time * 1000).getHours() + ':' + new Date(r.time * 1000).getMinutes()
						// console.log(r.time1 + ' ' +  time0)
						r.time = r.time1 + ' ' +  time0
					})
					this.$forceUpdate()
				})
			},
			
			// 获取全部信息表
			getAll() {
				// 获取今日
				this.$myRequest({
					url: '/getAllTemperature',
					data: {
						userid: this.adminId,
						userkey: this.adminKey,
						page: this.currentPage
					}
				}).then(res => {
					console.log(res.result.res)
					this.allPage = res.result.res.last_page * 10
					this.tableData = res.result.res.data
					this.tableData.forEach( (r,i) => {
						// console.log(r.time)
						let time0 = new Date(r.time * 1000).getHours() + ':' + new Date(r.time * 1000).getMinutes()
						// console.log(r.time1 + ' ' +  time0)
						r.time = r.time1 + ' ' +  time0
					})
					this.$forceUpdate()
				})
			},
		}

	}
</script>

<style scoped>
	.data_table {
		width: 100%;
	}
	.user_data_but{
		width: 100%;
		height: 200upx;
		border: 1upx solid #ebe5ef;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
</style>
