<template>
	<view>
		<view class="top_all">
			<view class="top_title">
				蓝牙体温计后台管理系统
			</view>
			<view class="top_admin">
				<image src="../static/me.jpg" mode=""></image>
				<view class="top_admin_name">
					{{ adminUse.adminId }}
				</view>
				<el-button type="danger" style="margin-left: 20upx;" plain @click="removeLogin">注销登录</el-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:"e_top",
		props:['adminUse'],
		data() {
			return {
				
			};
		},
		methods:{
			removeLogin(){
				console.log('注销登录')
				uni.removeStorageSync('ZXCW_ADMIN');
				uni.redirectTo({
				    url: '/pages/login/login'
				});
			}
		}
	}
</script>

<style>
	.top_all{
		width: 100%;
		height: 200upx;
		/* background-color: #0000FF; */
		border-bottom: 1upx solid #b9b9b9;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.top_title{
		margin-left: 50upx;
		font-size: 50upx;
		font-weight: 700;
	}
	.top_admin{
		display: flex;
		align-items: center;
		margin-right: 180upx;
	}
	.top_admin image{
		width: 90upx;
		height: 90upx;
		border-radius: 50%;
	}
	.top_admin_name{
		font-size: 40upx;
		margin-left: 20upx;
	}
</style>
