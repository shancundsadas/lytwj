<template>
	<view style="width: 50%;">
		<view class="All_title">
			权限修改
		</view>
		<view class="" style="width: 100%;">
			<el-form :label-position="labelPosition" label-width="80px" :model="formLabelAlign">
				<el-form-item label="账号">
					<el-input v-model="formLabelAlign.getUser" type="number"></el-input>
				</el-form-item>
				<el-form-item label="密码">
					<el-input v-model="formLabelAlign.getkey"></el-input>
				</el-form-item>
			</el-form>
		</view>
		<view class="" style="width: 100%;height: 70px;display: flex;align-items: center;font-size: 40upx;">
			权限分配
		</view>
		<view class="">
			<el-checkbox-group v-model="checkList">
				<el-checkbox label="a" v-show="showb[0]">添加管理用户</el-checkbox>
				<el-checkbox label="b" v-show="showb[1]">用户信息修改</el-checkbox>
				<el-checkbox label="c" v-show="showb[2]">查询用户信息详情</el-checkbox>
				<el-checkbox label="d" v-show="showb[3]">清空用户信息</el-checkbox>
				<view class="" style="width: 100%;height: 10px;">
					
				</view>
				<el-checkbox label="e" v-show="showb[4]">温度报表</el-checkbox>
				<el-checkbox label="f" v-show="showb[5]">查询用户的温度信息表 </el-checkbox>
				<el-checkbox label="g" v-show="showb[6]">设置用户权限</el-checkbox>
				<el-checkbox label="h" v-show="showb[7]">获取全部用户的报表</el-checkbox>
			</el-checkbox-group>
		</view>
		<view class="" style="width: 100%;height: 300px; display: flex; align-items: center;justify-content: center;">
			<el-button type="primary" @click="makeAdmin()">创建管理员</el-button>
		</view>
		
		<loading ref="loading" :custom="false" :shadeClick="false" :type="1" @callback="callback()">
			<!-- <view class="test">自定义</view> -->
		</loading>
	</view>
</template>

<script>
	import loading from './xuan-loading/xuan-loading.vue'
	export default {
		name: "admin_qx",
		props:['adminUse'],
		components:{
			loading
		},
		data() {
			return {
				labelPosition: 'right',
				adminId : '',
				adminKey : '',
				formLabelAlign: {
					getUser: '',
					getkey: ''
				},
				checkList: [],
				myQx : [],
				showb : [false,false,false,false,false,false,false,false]
			};
		},
		mounted() {
			this.adminId = this.adminUse.adminId
			this.adminKey = this.adminUse.adminKey
			this.getMyQx()
		},
		methods:{
			//创建用户
			makeAdmin(){
				if( this.formLabelAlign.getUser === ''){
					alert('请先输入账号')
					return
				}
				if( this.formLabelAlign.getkey === ''){
					alert('请先输入密码')
					return
				}
				// console.log(this.checkList)
				if(this.checkList.length === 0){
					alert('没有给权限哦')
					return
				}
				this.$refs.loading.open();
				let str = ''
				this.checkList.forEach( r => {
					if(str === ''){
						str = r
					}else{
						str = str + ','+ r
					}
				})
				
				// console.log(str)
				let key = this.$encryptDes(this.formLabelAlign.getkey)
				this.$myRequest({
					url : '/upUser',
					data : {
						userid : this.adminId,
						userkey : this.adminKey,
						getUser : this.formLabelAlign.getUser,
						getkey : key
					}
				}).then( r => {
					console.log(r)
					if(r.status === 1){
						this.$myRequest({
							url : '/QX',
							data : {
								userid : this.adminId,
								userkey : this.adminKey,
								getUser : this.formLabelAlign.getUser,
								str : str
							}
						}).then( res => {
							this.$refs.loading.close();
							// console.log('权限信息',res)
							alert(res.result.res)
						})
					}else{
						this.$refs.loading.close();
						// console.log('权限信息',res)
						alert(r.result.res)
					}
				})
			},
			// 查询自己的权限
			getMyQx(){
				this.$myRequest({
					url : '/searchqx',
					data : {
						userid : this.adminId,
						userkey : this.adminKey
					}
				}).then( res => {
					// 获得的权限
					// console.log(res.result.res[0].verification)
					this.myQx = res.result.res[0].verification.split(',')
					// console.log(this.myQx)
					this.myQx.forEach( r => {
						if(r === 'a'){
							this.showb[0] = true
						}else if(r === 'b'){
							this.showb[1] = true
						}else if(r === 'c'){
							this.showb[2] = true
						}else if(r === 'd'){
							this.showb[3] = true
						}else if(r === 'e'){
							this.showb[4] = true
						}else if(r === 'f'){
							this.showb[5] = true
						}else if(r === 'g'){
							this.showb[6] = true
						}else if(r === 'h'){
							this.showb[7] = true
						}
					})
					this.$forceUpdate()
				})
			}
		}
	
	}
</script>

<style>

</style>
