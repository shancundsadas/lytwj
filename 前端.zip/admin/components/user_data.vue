<template>
	<view>
		<view class="All_title">
			用户信息
		</view>
		<view class="user_data_but">
			<el-button type="primary" @click="url = '/getAllUser'">查看全部</el-button>
			<el-button type="primary">主要按钮</el-button>
			<el-button type="primary">查看今日未测温</el-button>
		</view>
		<view class="data_table">
			<el-table :data="tableData" border style="width:100%">
				<el-table-column fixed prop="user_id" label="用户ID" width="150">
				</el-table-column>
				<el-table-column prop="name" label="姓名" width="120">
				</el-table-column>
				<el-table-column prop="phone" label="电话" width="200">
				</el-table-column>
				<el-table-column prop="today_first" label="上午体温" width="120">
				</el-table-column>
				<el-table-column prop="today_second" label="下午体温" width="120">
				</el-table-column>
				<el-table-column fixed="right" label="查看用户" width="170">
					<template slot-scope="scope">
						<el-button @click="seeUserTem(scope.row)" type="primary" style="">
							查看用户体温曲线
						</el-button>
					</template>
				</el-table-column>
				<el-table-column fixed="right" label="查看用户" width="120">
					<template slot-scope="scope">
						<el-button @click="handleClick(scope.row)" type="primary" style="">
							查看用户
						</el-button>
					</template>
				</el-table-column>
				<el-table-column fixed="right" label="清除用户" width="120">
					<template slot-scope="scope">
						<el-button @click="delectUser(scope.row.user_id)" type="text" size="small">
							<el-button type="danger">清除用户</el-button>
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			<el-pagination background layout="prev, pager, next" :total="allPage" :current-page.sync="currentPage"
				@current-change="current_change" style="text-align: center;margin-top: 100upx;">
			</el-pagination>
		</view>

		<!-- 用户信息查看弹出窗 -->
		<el-drawer title="用户信息" :visible.sync="drawer" direction="ttb" :before-close="handleClose" style="height: 2000px;">
			<el-form ref="form" :model="getUser" label-width="550px">
				<view class="" style="width: 100%;height: 90upx;margin-left: 500px; font-weight: 700;">
					用户ID：{{ getUser.user_id }}
				</view>
			  <el-form-item label="用户姓名">
			    <el-input v-model="getUser.name" style="width: 1000upx;"></el-input>
			  </el-form-item>
			  
			  <el-form-item label="用户手机号">
			    <el-input v-model="getUser.phone" style="width: 1000upx;"></el-input>
			  </el-form-item>
			  
			  <el-form-item label="用户身份证号">
			    <el-input v-model="getUser.idNumber" style="width: 1000upx;"></el-input>
			  </el-form-item>
			  <el-form-item label="用户家庭住址">
			    <el-input v-model="getUser.userAdress" style="width: 1000upx;"></el-input>
			  </el-form-item>
			  
			  <el-form-item label="用户性别">
			    <el-input v-model="getUser.sex" style="width: 1000upx;"></el-input>
			  </el-form-item>
			  
			  <el-form-item label="蓝牙体温地址">
			    <el-input v-model="getUser.ifBind" style="width: 1000upx;"></el-input>
			  </el-form-item>
			</el-form>
			<view class="" style="width: 100%; text-align: center;">
				<el-button type="primary" @click="upUserData">保存修改信息</el-button>
			</view>
			
		</el-drawer>


<!-- 用户温度信息曲线 -->
		<el-drawer
		  title="用户温度表格"
		  :visible.sync="drawer1"
		  v-if="drawer1"
		  :before-close="handleClose"
		  >
		  <!-- 查看温度曲线 -->
		  <temChart :searchData="searchData"/>
		</el-drawer>
	</view>
</template>

<script>
	import temChart from './tem_chart.vue'
	export default {
		name: "user_data",
		props:['adminUse'],
		data() {
			return {
				total: '',
				currentPage: 1, //当前页
				temPage : 1,//用户温度
				tableData: [],
				allPage: 0,
				drawer: false,
				drawer1: false,
				getUser : {},
				url : '',
				userTemData : [],
				adminId : '',
				adminKey : '',
				searchData : {}
			};
		},
		components:{
			temChart
		},
		mounted() {
			this.adminId = this.adminUse.adminId
			this.adminKey = this.adminUse.adminKey
			this.getUserData() 	
		},
		watch: {
			currentPage(value) {
				console.log('切换页面')
				this.getUserData()
			},
		},
		methods: {
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
			  .catch(_ => {});
			},
			// 查看用户温度曲线
			seeUserTem(value){
				// console.log('用户的信息',value.user_id)
				this.drawer1 = true
				// 发送ajax请求
				this.searchData = {
					adminId : this.adminId,
					adminKey : this.adminKey,
					userId : value.user_id
				}
			},
			handleClick(row) {
				console.log(row); //点击查看
				this.getUser = {}
				this.getUser = row
				this.drawer = true
			},
			current_change(currentPage) { //改变当前页
				this.currentPage = currentPage
				// console.log('当前页', currentPage)
			},
			getUserData() {
				// 获取全部用户信息
				this.$myRequest({
					url: '/getAllUser',
					data: {
						userid: this.adminId,
						userkey: this.adminKey,
						page: this.currentPage
					}
				}).then(res => {
					// console.log(res.result.res)
					this.allPage = res.result.res.last_page * 10
					this.tableData = res.result.res.data
					this.$forceUpdate()
				})
			},
			// 修改用户信息
			upUserData(){
				this.getUser.userid = this.adminId
				this.getUser.userkey = this.adminKey
				this.getUser.getuser = this.getUser.user_id
				this.$myRequest({
					url : '/changeUser',
					data : this.getUser,
				}).then( res => {
					console.log(res)
				})
			},
			
			// 删除用户
			delectUser(value) {
				uni.showModal({
					title: '警告信息',
					content: '情定删除吗？删除之后将彻底清除！',
					showCancel: true,
					success: (res) => {
						if (res.confirm) {
							// console.log('用户点击确定');
							// console.log(value)
							// 删除用户
							this.$myRequest({
								url: '/delUserData',
								data: {
									userid: this.adminId,
									userkey: this.adminKey,
									getuser: value
								}
							}).then(res => {
								// console.log(res)
								this.getUserData()
								this.$forceUpdate()
							})
						} else if (res.cancel) {
							// console.log('用户点击取消');
						}
					}
				});
			}
		}

	}
</script>

<style scoped>
	.data_table {
		width: 100%;
	}
	.user_data_but{
		width: 100%;
		height: 200upx;
		border: 1upx solid #ebe5ef;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
</style>
