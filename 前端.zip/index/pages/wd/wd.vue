<template>
	<view>
		<view class="wdTop">
			<view class="wdTop_text">
				<view class="text_left">
					今天温度：
				</view>
				<view class="text_right">
					{{ todayWd | changeTodayWd }}
				</view>
			</view>
			<image src="../../static/wdqx.png" mode="" @click="goChart"></image>
		</view>
		
		<z-paging ref="paging" v-model="wdData" @query="queryList" v-show="nowShow">
			<view slot="top" style="height: 200upx;"></view>
			<view class="wdCard">
				<wdCard v-for="(item,index) in wdData" :wdDatas="item" :id='index'></wdCard>
			</view>
		</z-paging>
		<view class="showNow" v-show="!nowShow">
			______请先登录______
		</view>
		
	</view>
</template>

<script>
	import wdCard from '../../components/wdCard.vue'
	export default {
		data() {
			return {
				wdData : [],
				nowShow : false,
				todayWd : '还没有测温哦!'
			}
		},
		onLoad() {
			this.ifToday()
		},
		onShow() {
			const token = uni.getStorageSync('ZXCW_USERMAIN');
			
			if(token){
				this.nowShow = true
			}else{
				this.nowShow = false
				this.todayWd = '还没有测温哦!'
			}
		},
		components:{
			wdCard
		},
		filters:{
			changeTodayWd(value){
				var arr = value.split('^')
				console.log('这是第一个',arr[0])
				if(arr[0] === 'null'  && arr[1] === 'null' || arr[0] === '0'  && arr[1] === '0' || arr[0] === '还没有测温哦!'){
					return '还没有测温哦!'
				}else{
					console.log(arr)
					if(arr[0] === '0' || arr[0] === 'null'){
						arr[0] = '未测'
					}
					if(arr[1] === '0' || arr[1] === 'null'){
						arr[1] = '未测'
					}
					return '上午:' + arr[0] +'    '+ '下午:' + arr[1]
				}
			}
		},
		methods: {
			//跳转到折线图
			goChart(){
				uni.navigateTo({
					url:'./chart/chart'
				})
			},
			queryList(pageNo,pageSize){
				console.log(pageNo,pageSize)
				var token = uni.getStorageSync('ZXCW_USERMAIN');
				const userData = uni.getStorageSync('ZXCW_USERDATA');
				token = this.$decryptDes(token)
				// 获取测温数据
				const myWd = this.$myRequest({
					url: '/getTemperature',
					method: 'post',
					data: {
						userid : userData.user_id,
						userMain : token,
						page : pageNo
					}
				})
				
				myWd.then(res => {
					console.log(res.result.res.data)
					this.$refs.paging.complete(res.result.res.data)
				})
			},
			// 判断今日温度是否正常
			ifToday(){
				var token = uni.getStorageSync('ZXCW_USERMAIN');
				const userData = uni.getStorageSync('ZXCW_USERDATA');
				token = this.$decryptDes(token)
				const today = this.$myRequest({
					url : '/getMyData',
					method : 'post',
					data : {
						userid : userData.user_id,
						userMain : token
					}
				})
				today.then( res => {
					console.log(res.result.res[0])
					// today_first  today_second 为第一次第二次
					if(res.result.res[0].today_first === '0' && res.result.res[0].today_second === '0'){
						
					}else{
						this.todayWd = res.result.res[0].today_first + '^' + res.result.res[0].today_second
					}
					
				})
			}
		}
	}
</script>

<style scoped>
	.wdTop{
		width: 100%;
		height: 200upx;
		background-color: #f8f8f8;
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		/* 固定到顶端 */
		position: sticky;
		top: 0px;
		z-index: 99;
	}
	.wdTop image{
		width: 70upx;
		height: 70upx;
		margin-right: 30upx;
		margin-bottom: 30upx;
	}
	.text_left{
		font-size: 35upx;
		font-weight: 700;
		margin-left: 30upx;
	}
	.text_right{
		font-size: 40upx;
		font-weight: 700;
		margin-left: 80upx;
	}
	.wdCard{
		
		width: 100%;
		background-color: #fbfbfb;
	}
	.showNow{
		width: 100%;
		height: 200upx;
		/* background-color: #006FA7; */
		font-size: 30upx;
		color: #919191;
		display: flex;
		align-items: flex-end;
		justify-content: center;
	}
</style>
