<template>
	<view>
		<view class="indexTop">

		</view>
		<view class="waiquan">

		</view>
		<view class="xianshi" @click="getwendu">
			<view :class="ztClass">
				{{ wd }}
			</view>
			<view class="indexText">
				当前状态：{{ zt }}
			</view>
		</view>
		<view class="container">
			<view class="wave">
			</view>
			
		</view>
		<!-- <view class="indexMiddel" @click="cw">
			<view class="indexMiddel_text">
				{{ wd }}
			</view>
		</view> -->
		<view class="cwBut" @click="nextCw" v-show="ifShow">
			再次测温
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				wz: '',
				list: [],
				serviceId: '',
				shiliu: '',
				result: '',
				wd: '等待设备...',
				zt: '未连接',
				ztClass: 'wd0',
				userDeviceId: '',
				bingenLy: false,
				ifShow : false
				// userDeviceId : 'D1:F0:01:01:D2:C5',//设备唯一标识 绑定的信息
			}
		},
		onLoad() {
			// console.log('测温')
			// this.liucheng()	
		},
		onShow() {
			// 每一次打开界面判断是否已经填写成功 成功之后的如果没有开启一次 开启一次然后往后就不开起了
			this.liucheng()
		},
		methods: {
			// 再次测温but
			nextCw(){
				console.log('测温')
				uni.showModal({
				    title: '提示',
				    content: '请先关闭电子测温计，然后点击确定！',
				    success:  (res) => {
				        if (res.confirm) {
				            // console.log('用户点击确定');
							// this.ifShow = false
							// this.bingenLy = false
							// this.wd = '等待设备...'
							// this.ztClass = 'wd0'
							// this.liucheng()
							// uni.switchTab({
							//     url: '/pages/index/index'
							// });
							uni.closeBLEConnection({
							  deviceId : this.deviceId,
							  success(res) {
							    console.log(res)
								uni.reLaunch({
									url: '/pages/index/index'
								})
							  }
							})
				        } else if (res.cancel) {
				            // console.log('用户点击取消');
				        }
				    }
				});
			},
			liucheng() {
				// 判断登录
				const token = uni.getStorageSync('ZXCW_USERMAIN');
				if (token) {
					// 用户已经登陆  判断用户是否填写信息
					var userData = uni.getStorageSync('ZXCW_USERDATA');
					if (userData.ifData) {
						// 已经填写信息了
						if (userData.ifBind) {
							const myAdress = uni.getStorageSync('ZXCW_GLXX');
							if (myAdress) {
								this.userDeviceId = userData.ifBind
								if (this.bingenLy === false) {
									this.firstBluetooth()
									this.bingenLy = true
								} else {
									console.log('蓝牙已经开启')
								}
							} else {
								uni.showToast({
									title: '请先填写隔离地址',
									icon: 'none'
								})
								setTimeout(() => {
									uni.switchTab({
										url: '../my/my',
									})
								}, 1500)
							}
						} else {
							uni.showToast({
								title: '请先绑定蓝牙设备',
								icon: 'none'
							})
							setTimeout(() => {
								uni.navigateTo({
									url: './searchMac/searchMac',

								})
							}, 1500)
						}

					} else {
						uni.showToast({
							title: '请先填写详细信息',
							icon: 'none'
						})
						setTimeout(() => {

							uni.navigateTo({
								url: '../my/fromUp/fromUp'
							})
						}, 1500)

					}
				} else {
					uni.navigateTo({
						url: '../my/login/login'
					})
				}
			},


			//跳转到搜索设备
			goSearchMac() {
				uni.navigateTo({
					url: './searchMac/searchMac'
				})
			},
			//1.初始化蓝牙
			firstBluetooth() {
				uni.openBluetoothAdapter({
					success: (res) => { //已打开
						uni.getBluetoothAdapterState({ //蓝牙的匹配状态
							success: (res1) => {
								console.log(res1, '“本机设备的蓝牙已打开”')
								//搜索蓝牙设备
								this.startBluetoothDeviceDiscovery()
							},
							fail: (err) => {
								uni.showToast({
									icon: 'none',
									title: '查看手机蓝牙是否打开'
								})
							}
						})
					},
					fail: err => { //未打开 
						uni.showToast({
							icon: 'error',
							title: '请先打开蓝牙'
						});
					}
				})
			},
			//2.搜索蓝牙设备
			// 开始搜索蓝牙设备
			startBluetoothDeviceDiscovery() {
				uni.startBluetoothDevicesDiscovery({
					success: (res) => {
						console.log('蓝牙设备搜索 ：', res)
						// 发现外围设备
						this.onBluetoothDeviceFound()
					},
					fail: err => {
						console.log(err, '错误信息')
					}
				})
			},
			//3.发现设备
			// 发现外围设备
			onBluetoothDeviceFound() {
				// console.log("zhixing")
				uni.onBluetoothDeviceFound((res) => {
					// console.log('这是搜索的设备的json',res)
					// ["name", "deviceId"]
					// 吧搜索到的设备存储起来，方便我们在页面上展示
					// if(this.list.indexOf(res.devices[0].deviceId)==-1){
					// 	this.list.push(res.devices[0].deviceId)
					// }
					if (this.list.indexOf(res.devices[0]) == -1) {
						this.list.push(res.devices[0])

						//这里是不是可以看到设备的唯一ID
						// console.log('设备唯一ID',res.devices[0].deviceId)
						// D1:F0:01:01:D2:C5
						// if (res.devices[0].name === 'Bluetooth BP') {

						//这里获取一下设备的devicId 绑定用户
						if (res.devices[0].deviceId === this.userDeviceId) {
							
							this.wd = '正在测温'
							this.zt = '已连接'
							this.ifShow = true
							uni.showToast({
								icon: 'none',
								title: '连接成功'
							});
							console.log('搜索到温度计', res.devices[0].deviceId)
							this.createBLEConnection(res.devices[0].deviceId)
						}
					}
				})
			},
			//4.选择要连接的设备
			//选择设备连接吧deviceId传进来
			createBLEConnection(deviceId) {
				let thit = this
				//data里面建立一个deviceId，存储起来
				this.deviceId = deviceId
				// console.log('保存的地址', deviceId)
				//连接蓝牙
				uni.createBLEConnection({
					// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
					deviceId: this.deviceId,
					success: (res) => {
						//防止在这里面取不到this，古在外面用thit存储了this
						thit.stopBluetoothDevicesDiscovery()
						console.log(res)
						// console.log("蓝牙连接成功")
						this.getBLEDeviceServices()
						
					},
					fail: (res) => {
						console.log("蓝牙连接失败", res)
					}
				})
			},
			//连接设备号 一定到停止搜索
			//5. 停止搜寻蓝牙设备
			stopBluetoothDevicesDiscovery() {
				uni.stopBluetoothDevicesDiscovery({
					success: e => {
						this.loading = false
						console.log('停止搜索蓝牙设备:' + e.errMsg);
					},
					fail: e => {
						console.log('停止搜索蓝牙设备失败，错误码：' + e.errCode);
					}
				});
			},

			//6.获取蓝牙设备的所有服务
			//获取蓝牙的所有服务
			getBLEDeviceServices() {
				setTimeout(() => {
					uni.getBLEDeviceServices({
						// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链
						deviceId: this.deviceId,
						success: (res) => {
							// console.log("成功",res)
							console.log('device services:', res)
							//这里会获取到好多个services  uuid  我们只存储我们需要用到的就行，这个uuid一般硬件厂家会给我们提供
							res.services.forEach((item) => {
								if (item.uuid.indexOf("00805F9B34FB") != -1) {
									// console.log('先运行的这个吗？')
									
									this.serviceId = item.uuid;
									//存储到状态
									// 这里获取回调，读取成功就的值就会在这个地方接收到！！！
									uni.onBLECharacteristicValueChange((res) => {
										this.disconnectBle()
										// 再转换为json
										// console.log('温度16进制', this.ab2hex(res.value))
										this.wd = this.newData(this.ab2hex(res.value))
										// console.log(this.wd)
										// 上传温度
										var token = uni.getStorageSync(
											'ZXCW_USERMAIN');
										var token = this.$decryptDes(token)
										const userData = uni.getStorageSync(
											'ZXCW_USERDATA');
										const myAdress = uni.getStorageSync(
											'ZXCW_GLXX');

										const r = this.$myRequest({
											url: '/upTemperature',
											method: 'post',
											data: {
												userid: userData.user_id,
												userMain: token,
												temperature: this.wd,
												adress: myAdress.address1
											}
										}).then(res => {
											console.log(res.result)
										})
										this.ifShow = true
										uni.showToast({
											icon: 'none',
											title: '测温完成'
										});
										
										if (this.wd < 37.3) {
											this.ztClass = 'wd'
										} else {
											this.ztClass = 'wd1'
										}
										this.$forceUpdate()
										// console.log('温度', this.HexToSingle(this.ab2hex(
										// 	res.value)))
											
									})
									// console.log('还是先运行的这个')
									this.getBLEDeviceCharacteristics()
								}


							})
						}
					})
				}, 1500)
			},
			//7.获取蓝牙特征
			//获取蓝牙特征
			getBLEDeviceCharacteristics() {
				console.log("进入特征");
				setTimeout(() => {
					uni.getBLEDeviceCharacteristics({
						// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
						deviceId: this.deviceId,
						// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
						serviceId: this.serviceId,
						success: (res) => {
							// console.log(res, '特征getBLEDeviceCharacteristics')
							this.characteristics = res.characteristics
							console.log(this.characteristics)
							//循环所有的uuid

							// for(let i=0;i<3;i++){
							// 	this.notifyBLECharacteristicValueChange(res.characteristics[i].uuid)
							// 	console.log(res.characteristics[i].uuid)
							// 	console.log(i,'i')
							// }
							res.characteristics.forEach((item) => {
								if (item.uuid.indexOf("00805F9B34FB") != -1) {
									// console.log('characteristicId:', item.uuid)
									//利用传参的形势传给下面的notify，这里的uuid如果都需要用到，就不用做判断了，建议使用setTimeout进行间隔性的调用此方法
									this.notifyBLECharacteristicValueChange(item.uuid)
								}
							})

						},
						fail: (res) => {
							console.log(res)
						}
					})
				}, 1000)
			},
			//8.启用蓝牙设备特征值变化时的 notify 功能
			// 启用 notify 功能
			notifyBLECharacteristicValueChange(characteristicId) {
				console.log(characteristicId, 'characteristicId')
				uni.notifyBLECharacteristicValueChange({
					state: true, // 启用 notify 功能
					// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
					deviceId: this.deviceId,
					// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
					serviceId: this.serviceId,
					// 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
					characteristicId: characteristicId,
					success: (res) => {
						console.log(res)
						// console.log(this.characteristicId)
						console.log('notifyBLECharacteristicValueChange success', res.errMsg)
					},
					fail: (res) => {
						console.log('notifyBLECharacteristicValueChange success2', res.errMsg)
					}
				})
			},
			/* 断开低功耗蓝牙的连接 */
			disconnectBle(){
				uni.closeBLEConnection({
					deviceId:this.deviceId,
					success: (res) => {
						console.log("断开成功" + res)
					}
				})
			},
			//读取数据转换10进制
			ab2hex(buffer) {
				const hexArr = Array.prototype.map.call(
					new Uint8Array(buffer),
					function(bit) {
						return ('00' + bit.toString(16)).slice(-2)
					}
				)
				return hexArr.join('')
			},
			//3.温度数据处理
			newData(value) {
				//摄氏度
				let th = parseInt(value.slice(8, 10))
				let tl = parseInt(value.slice(10, 12), 16)
				return (th * 256 + tl) / 10
			},
			//4.摄氏度转华氏度
			getFahrenheit(value) {
				return value * 9 / 5 + 32
			},
			//获取当前位置
			getWZ() {
				console.log('获取地理位置')
				uni.getLocation({
					type: 'wgs84',
					geocode: true,
					success: (res) => {
						console.log(res.address);
						this.wz = res.address
					},
					fail: (res) => {
						console.log(res);
						this.wz = res
					}
				});

			},
			//重新测温
			getwendu() {
				console.log(1)
				this.firstBluetooth()
			}
		}
	}
</script>

<style scoped>
	.indexTop {
		width: 100%;
		height: 300upx;
	}

	.xianshi {
		/* background-color: #006FA7; */
		position: absolute;
		z-index: 99;
		width: 100%;
		top: 430upx;
	}

	.indexMiddel {
		width: 450upx;
		height: 450upx;
		border-radius: 50%;
		background-size: 100% 100%;
		display: flex;
		background-image: url(../../static/bjt.png);
		/* background-image: bjt; */
		margin: 0upx auto 0upx auto;
		align-items: center;
		justify-content: center;
	}

	/* 外圈 */
	.waiquan {
		width: 650upx;
		height: 650upx;
		position: absolute;
		border: 5px solid #f6f9fe;
		/* background-color: #000000; */
		border-radius: 50%;
		left: 5.5%;

		top: 12%;
	}

	/* 正常体温 */
	.wd {
		width: 100%;
		text-align: center;
		font-size: 90upx;
		font-weight: 700;
		color: #2580eb;
		height: 450upx;
	}

	/* 高体温 */
	.wd1 {
		width: 100%;
		text-align: center;
		font-size: 90upx;
		font-weight: 700;
		color: #ff0000;
		height: 450upx;
	}

	/* 原状态 */
	.wd0 {
		width: 100%;
		text-align: center;
		font-size: 50upx;
		font-weight: 700;
		color: #747474;
		height: 450upx;
	}

	.indexText {
		width: 100%;
		text-align: center;
		font-size: 30upx;
		font-weight: 700;
		color: #a8a8a8;
		/* margin-top: 300upx; */
	}

	.wave p {
		margin-top: 30%;

	}

	.indexMiddel_text {
		font-size: 70upx;
		font-weight: 700;
		color: #006fa7;
	}

	.container {
		position: absolute;
		width: 500upx;
		height: 500upx;
		padding: 5px;
		/* 最外外全 */
		border-top: 5px solid #2580eb;
		border-left: 5px solid #2580eb;
		border-right: 5px solid #2580eb;
		top: 530upx;
		left: 50%;
		transform: translate(-50%, -50%);
		border-radius: 50%;
		overflow: hidden;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.wave {
		position: relative;
		width: 200px;
		height: 200px;
		/* 最外圈 */
		background-color: #ffffff;
		border-radius: 50%;
	}

	.wave:before,
	.wave:after {
		content: "";
		position: absolute;
		width: 90%;
		height: 90%;
		top: 70%;
		left: 50%;
		/* 中圈颜色 */
		background-color: #afd3f7;

		border-radius: 40%;
		transform: translate(-50%, -70%) rotate(0);
		animation: rotate 6s linear infinite;
		z-index: 10;
	}

	.wave:after {
		border-radius: 40%;
		/* 最内圈颜色 */
		/* background-color: #b0d2f7; */
		background: linear-gradient(to right, #86b8f3, #eef5fd);
		transform: translate(-50%, -70%) rotate(0);
		animation: rotate 10s linear -5s infinite;
		z-index: 20;
	}

	@keyframes rotate {
		50% {
			transform: translate(-50%, -73%) rotate(180deg);
		}

		100% {
			transform: translate(-50%, -70%) rotate(360deg);
		}
	}

	.cwBut {
		width: 300upx;
		height: 80upx;
		position: absolute;
		top: 1100upx;
		left: 225upx;
		border-radius: 30upx;
		border-radius: 58px;
		border-radius: 13px;
		background: #f8fbfb;
		box-shadow: 8px 8px 16px #DFECFB,
			-8px -8px 16px #ffffff;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 35upx;
		color: #7fb3e3;
		font-weight: 700;
	}
</style>
