<template>
	<view>
		<view class="search_mac" style="position:fixed;top: 360upx;left: 155upx;" v-show="idShow[0],list[0]" @click="bind(idBind[0])">
			<image src="../../../static/index/wdj.png" mode=""></image>
		</view>
		
		<view class="search_mac" style="position:fixed;top: 400upx;left: 530upx;" v-show="idShow[1],list[1]" @click="bind(idBind[1])">
			<image src="../../../static/index/wdj.png" mode=""></image>
		</view>
		
		<view class="search_mac" style="position:fixed;top: 600upx;left: 80upx;" v-show="idShow[2],list[2]" @click="bind(idBind[2])">
			<image src="../../../static/index/wdj.png" mode=""></image>
		</view>
		
		<view class="search_mac" style="position:fixed;top: 800upx;left: 80upx;" v-show="idShow[3],list[3]" @click="bind(idBind[3])">
			<image src="../../../static/index/wdj.png" mode=""></image>
		</view>
		
		<view class="search_mac" style="position:fixed;top: 700upx;left: 580upx;" v-show="idShow[4],list[4]" @click="bind(idBind[4])">
			<image src="../../../static/index/wdj.png" mode=""></image>
		</view>
		
		<view class="searchImg">
			<image src="../../../static/index/search.gif" mode=""></image>
			<p>{{ text }}</p>
		</view>
		<loading
		    ref="loading"
		    :custom="false"
		    :shadeClick="true"
		    :type="1"
		    @callback="callback()">
		        <!-- <view class="test">自定义</view> -->
		</loading>
	</view>
</template>

<script>
	import loading from '../../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				text : '正在搜索',
				wz: '',
				list: [],
				serviceId: '',
				shiliu: '',
				result: '',
				wd: '等待设备...',
				zt: '未连接',
				ztClass : 'wd0',
				idShow : [false,false,false,false,false],//搜索设备后显示
				idBind : [],
				idNow : 0,
			}
		},
		components:{
			loading
		},
		onLoad() {
			this.makeText()
			this.firstBluetooth()
		},
		methods: {
			//实现text加点
			makeText(){
				setInterval(r => {
					// this.text = '正在搜索.'
					// console.log(this.text) 
					if(this.text === '正在搜索'){
						this.text = '正在搜索 .'
					}else if(this.text === '正在搜索 .'){
						this.text = '正在搜索 . .'
					}else if(this.text === '正在搜索 . .'){
						this.text = '正在搜索 . . .'
					}else if(this.text === '正在搜索 . . .'){
						this.text = '正在搜索'
					}
				},500)
			},
			
			//1.初始化蓝牙
			firstBluetooth() {
				uni.openBluetoothAdapter({
					success: (res) => { //已打开
						uni.getBluetoothAdapterState({ //蓝牙的匹配状态
							success: (res1) => {
								console.log(res1, '“本机设备的蓝牙已打开”')
								//搜索蓝牙设备
								this.startBluetoothDeviceDiscovery()
							},
							fail: (err) => {
								uni.showToast({
									icon: 'none',
									title: '查看手机蓝牙是否打开'
								})
							}
						})
					},
					fail: err => { //未打开 
						uni.showToast({
							icon: 'error',
							title: '请先打开蓝牙'
						});
					}
				})
			},
			//2.搜索蓝牙设备
			// 开始搜索蓝牙设备
			startBluetoothDeviceDiscovery() {
				uni.startBluetoothDevicesDiscovery({
					success: (res) => {
						console.log('蓝牙设备搜索 ：', res)
						// 发现外围设备
						this.onBluetoothDeviceFound()
					},
					fail: err => {
						console.log(err, '错误信息')
					}
				})
			},
			//3.发现设备
			// 发现外围设备
			onBluetoothDeviceFound() {
				// console.log("zhixing")
				uni.onBluetoothDeviceFound((res) => {
					// console.log('这是搜索的设备的json',res)
					// ["name", "deviceId"]
					// 把搜索到的设备存储起来，方便我们在页面上展示
					if(this.list.indexOf(res.devices[0].deviceId)==-1){
						this.list.push(res.devices[0].deviceId)
					}
					if (this.list.indexOf(res.devices[0]) == -1) {
						this.list.push(res.devices[0])
						
						//这里是不是可以看到设备的唯一ID
						
						// D1:F0:01:01:D2:C5
						if (res.devices[0].name === 'Bluetooth BP') {
							
								//在这里可以发现设备
								console.log('来了一个设备',res.devices[0].deviceId)
								// 显示设备
								// 发送AJAX请求
								
								this.$myRequest({
									url : '/ifBinded',
									method : 'post',
									data : {
										macId : res.devices[0].deviceId
									}
								}).then( r => {
									console.log(r)
									if(r.status === 1){
										console.log('这个是第几个设备',this.idNow)
										this.idBind[this.idNow] = res.devices[0].deviceId
										this.idShow[this.idNow] = true
										console.log('这个是第几个设备', res.devices[0].deviceId)
										this.idNow ++
										console.log('这个是第几个设备',this.idNow)
										this.$forceUpdate()
									}
								})
							//关闭蓝牙
							// this.stopBluetoothDevicesDiscovery()
						}
					}
				})
			},
			
			//连接设备号 一定到停止搜索
			//5. 停止搜寻蓝牙设备
			stopBluetoothDevicesDiscovery() {
				uni.stopBluetoothDevicesDiscovery({
					success: e => {
						this.loading = false
						console.log('停止搜索蓝牙设备:' + e.errMsg);
					},
					fail: e => {
						console.log('停止搜索蓝牙设备失败，错误码：' + e.errCode);
					}
				});
			},
			
			//点击了设备发现
			bind(value,macId){
				console.log(value)
				uni.showActionSheet({
					itemList: ['确认绑定'],
					success: (res) => {
						// //console.log('选中了第' + (res.tapIndex + 1) + '个按钮');
						switch (res.tapIndex) {
							case 0:
							this.$refs.loading.open();
								console.log("确认绑定")
								this.stopBluetoothDevicesDiscovery() //停止搜索
								this.bindMac(value)  //发送绑定信息
								break
						}
					},
					fail: function(res) {
						//console.log(res.errMsg);
					}
				})
			},
			// 绑定设备
			bindMac(macid){
				console.log('调用绑定设备',macid)
				var token = uni.getStorageSync('ZXCW_USERMAIN');
				token = this.$decryptDes(token)
				var userData = uni.getStorageSync('ZXCW_USERDATA');
				// 
				const bind = this.$myRequest({
					url: '/upUserBind',
					method: 'post',
					data: {
						userid : userData.user_id,
						userMain : token,
						ifBind : macid
					}
				})
				bind.then(res => {
					console.log(res.status)
					if(res.status === 1){
						console.log('返回值来了')
						let userData = uni.getStorageSync('ZXCW_USERDATA');
						userData.ifBind = macid
						console.log('发送的东西来了',userData.ifBind)
						console.log('当前用户',userData)
						uni.setStorage({
						    key: 'ZXCW_USERDATA',
						    data: userData,
						    success:  () => {
						        console.log('success');
								this.$refs.loading.close();
								uni.showToast({
									title:'修改成功',
								})
								setTimeout(() => {
									uni.switchTab({
									    url: '/pages/index/index'
									});
								},1000)
						    }
						});
						
					}
				})
			}
		}
	}
</script>

<style scoped>
	.searchImg{
		width: 300upx;
		height: 300upx;
		position:fixed;
		top: 500upx;
		left: 225upx;
		
	}
	.searchImg image{
		width: 100%;
		height: 100%;
		border-radius: 50%;
	}
	.searchImg p{
		font-size: 33upx;
		font-weight: 700;
		margin-left: 60upx;
		margin-top: 20upx;
	}
	.search_mac{
		width: 90upx;
		height: 90upx;
		border-radius: 50%;
		background-color: #aac7df;
		display: flex;
		align-items: center;
		justify-content: center;
		box-shadow: 5px 5px 6px #e1e1e1;
	}
	.search_mac image{
		width: 70%;
		height: 70%;
	}
</style>
