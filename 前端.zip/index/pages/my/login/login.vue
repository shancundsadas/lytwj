<!-- 蓝色登录页面2 -->
<template>

	<view>

		<view class="topClass">
			<view class="bigTitle">你好，欢迎登陆</view>
			<view class="smailTitle">
				没有账户？<a style="color: #007AFF;" @click="reg">立即注册</a>
			</view>
		</view>

		<view class="login-view" style="">
			<view class="t-login">
				<form class="cl">
					<view class="t-a">
						<text class="txt">账号</text>
						<input type="number" name="phone" placeholder="请输入您的账号" maxlength="11" v-model="phone" />
					</view>
					<view class="t-a">
						<text class="txt">密码</text>
						<input type="password" name="code" maxlength="18" placeholder="请输入您的密码" v-model="pwd" />
					</view>
					<view class="wjmm">
						<!-- 忘记密码？ -->
						.
					</view>
					<button :class="leaveClass" v-show="ifLogin" @tap="login()">登 录</button>

				</form>
				<view class="t-f"><text>—————— 第三方账号登录 ——————</text></view>
				<!-- <view class="t-e cl">
					<view class="t-g" @tap="wxLogin()">
						<image src="../../../static/my/wx.png"></image>
					</view>
					<view class="t-g" @tap="qqLogin()">
						<image src="../../../static/my/qq.png"></image>
					</view>
				</view> -->
				<view class="ty">
					<label class="radio">
						<!-- <radio checked="true" value="" /><text>你已阅读并同意 《烟理盒子用户条约》</text> -->
					</label>
				</view>
			</view>
		</view>
		<loading ref="loading" :custom="false" :shadeClick="true" :type="1" @callback="callback()">
			<!-- <view class="test">自定义</view> -->
		</loading>
	</view>
</template>
<script>
	import loading from '../../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				phone: '', //账号
				pwd: '', //密码,
				ifLogin: true,
				// animate__animated animate__backOutLeft
				leaveClass: "",
				check: false
			};
		},
		components: {
			loading
		},
		onLoad() {},
		methods: {
			//加载动画
			close: function() {
				this.$refs.loading.close();
			},
			open: function() {
				this.$refs.loading.open();
			},
			callback() {
				//console.log("回掉");
			},


			//当前登录按钮操作
			login() {
				var that = this;
				if (!that.phone) {
					uni.showToast({
						title: '请输入您的账号',
						icon: 'none'
					});
					return;
				}
				if (!that.pwd) {
					uni.showToast({
						title: '请输入您的密码',
						icon: 'none'
					});
					return;
				}
				this.open()
				var newCookey = 'y' + this.pwd + 'l' + this.phone + 'h.z'
				//console.log(this.pwd)
				newCookey = this.$encryptDes(newCookey)
				// newCookey = this.$md5(newCookey) 
				//md5加密成功
				//console.log(newCookey)
				// 注册
				var userid = Number(this.phone);
				var data = {
					"userid": userid,
					'userkey': newCookey
				}
				const login = this.$myRequest({
					url: '/userLogin',
					method: 'post',
					data: data
				})

				login.then((res) => {
					if (res.status === 1) {
						console.log('用户返回信息',res.result.res[0])
						console.log('token',res.result.userMain)
						let token = this.$encryptDes(res.result.userMain,'token')
						//登陆成功
						var data = {
							user_id: res.result.res[0].user_id,
							user_name: res.result.res[0].name,
							ifData : res.result.res[0].ifData,
							ifBind : res.result.res[0].ifBind
						}
						
						//将数据写入本地
						uni.setStorage({
							key: 'ZXCW_USERDATA',
							data: data,
							success: () => {
								uni.setStorage({
									key: 'ZXCW_USERMAIN',
									data: token,
									success: () => {
										this.close()
										uni.showToast({
											title: "登陆成功！欢迎回来！",
											icon: "none"
										})
										setTimeout(() => {
											//这边直接跳转
											uni.switchTab({
												url: "../my"
											})
										}, 1300)
									}
								});
							}
						});
					} else {
						this.close()
						uni.showToast({
							title: res.result.res,
							icon: "none"
						})
					}
				})

			},
			//注册按钮点击
			reg() {
				uni.redirectTo({
					url: '../register/register'
				})

				// uni.showToast({
				// 	title: '注册跳转',
				// 	icon: 'none'
				// });
			},
			//等三方微信登录
			wxLogin() {
				// uni.showToast({ title: '微信登录', icon: 'none' });

				//console.log("点击成功！")
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						//console.log(loginRes.authResult);
						uni.getUserInfo({
							success: (info) => {
								// 用户id姓名 照片
								// //console.log(info.userInfo)
								// //console.log(info.userInfo.openId, info.userInfo.nickName, info
								// 	.userInfo.avatarUrl, )
								//将id存入本地
								uni.setStorage({
									key: 'YLHZ_LOGIN',
									data: info.userInfo.openId,
									success: function() {
										//console.log('success', info.userInfo.openId);
										uni.showToast({
											title: "登陆成功！欢迎回来！",
											icon: "none"
										})
										//这边直接跳转
										uni.switchTab({
											url: "../my/my"
										})
									}
								});

							}
						})
					}
				});
			},
			
			//第三方支付宝登录
			qqLogin() {
				uni.login({
					provider: 'qq',
					success: function(loginRes) {
						//console.log(loginRes.authResult);
						// uni.getUserProfile(); // 获取用户信息
						uni.getUserProfile({
							desc: "登录烟理盒子",
							lang: "zh_CN",
							success: (info) => {
								// 用户id姓名 照片
								//console.log(info.userInfo)
								// console.log(info.userInfo.openId, info.userInfo.nickName, info
								// 	.userInfo.avatarUrl, )
								//将id存入本地
								uni.setStorage({
									key: 'YLHZ_LOGIN',
									data: info.userInfo.openId,
									success: function() {
										//console.log('success', info.userInfo.openId);
										uni.showToast({
											title: "登陆成功！欢迎回来！",
											icon: "none"
										})
										setTimeout(() => {
											//这边直接跳转
											uni.switchTab({
												url: "../my/my"
											})
										}, 2000)
									}
								});

							}
						})
					}
				});
			}
		}
	};
</script>
<style scoped>
	.topClass {
		width: 85%;
		margin-left: auto;
		margin-right: auto;
		height: 360upx;
		/* background-color: #007AFF; */
		display: flex;
		justify-content: flex-end;
		flex-direction: column;
	}

	.bigTitle {
		/* height: 100upx; */
		font-size: 60upx;
		font-weight: 700;
	}

	.smailTitle {
		color: #5B5B5B;
		font-size: 33upx;
	}

	.wjmm {
		font-size: 30upx;
		font-weight: 800;
		margin-top: -25upx;
		margin-bottom: 60upx;
		/* color: #007AFF; */
	}

	.ty {
		text-align: center;
		margin-top: 20upx;
	}


	.txt {
		font-size: 32rpx;
		font-weight: bold;
		color: #333333;
	}

	.img-a {
		width: 100%;
		height: 450rpx;
		background-image: url(../../../static/my/head.png);
		background-size: 100%;
	}

	.reg {
		font-size: 28rpx;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
		background: #f5f6fa;
		color: #000000;
		text-align: center;
		margin-top: 30rpx;
	}

	.login-view {
		width: 100%;
		position: relative;

		background-color: #ffffff;
		border-radius: 8% 8% 0% 0;
	}

	.t-login {
		width: 85%;
		margin: 0 auto;
		font-size: 28rpx;
		padding-top: 60upx;
	}

	.t-login button {
		font-size: 28rpx;
		background: #2796f2;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
	}

	.t-login input {
		height: 90rpx;
		line-height: 90rpx;
		margin-bottom: 50rpx;
		border-bottom: 1px solid #e9e9e9;
		font-size: 28rpx;

	}

	.t-login .t-a {
		position: relative;
	}

	.t-b {
		text-align: left;
		font-size: 42rpx;
		color: #ffffff;
		padding: 130rpx 0 0 70rpx;
		font-weight: bold;
		line-height: 70rpx;
	}

	.t-login .t-c {
		position: absolute;
		right: 22rpx;
		top: 22rpx;
		background: #5677fc;
		color: #fff;
		font-size: 24rpx;
		border-radius: 50rpx;
		height: 50rpx;
		line-height: 50rpx;
		padding: 0 25rpx;
	}

	.t-login .t-d {
		text-align: center;
		color: #999;
		margin: 80rpx 0;
	}

	.t-login .t-e {
		text-align: center;
		width: 250rpx;
		margin: 80rpx auto 0;
	}

	.t-login .t-g {
		float: left;
		width: 50%;
	}

	.t-login .t-e image {
		width: 50rpx;
		height: 50rpx;
	}

	.t-login .t-f {
		text-align: center;
		margin: 300upx 0 0 0;
		color: #666;
	}

	.t-login .t-f text {
		margin-left: 20rpx;
		color: #aaaaaa;
		font-size: 27rpx;
	}

	.t-login .uni-input-placeholder {
		color: #aeaeae;
	}

	.cl {
		zoom: 1;
	}

	.cl:after {
		clear: both;
		display: block;
		visibility: hidden;
		height: 0;
		content: '\20';
	}
</style>
