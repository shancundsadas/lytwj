<template>
	<view>
		<view class="topClass">
			<view class="bigTitle">注册</view>
			<view class="smailTitle">
				已有账户？<a style="color: #007AFF;" @click="reg">立即登录</a>
			</view>
		</view>
	
		<view class="login-view" style="">
			<view class="t-login">
				<form class="cl">
					<view class="t-a">
						<text class="txt">手机号</text>
						<input type="number" name="phone" placeholder="请输入您的账号" maxlength="11" v-model="phone" />
					</view>
					<!-- <view class="t-a">
						<text class="txt">验证码</text>
						<view class="" style="display: flex; align-items: baseline">
							<input type="text" name="code" maxlength="18" placeholder="输入验证码" v-model="yz" />
							<view @click="getYzm" style="width: 200upx; margin-left: 30upx; font-size: 30upx;" :class="yzm">
								{{ time }}
							</view>
						</view>
					</view> -->
					<view class="t-a">
						<text class="txt">密码</text>
						<input type="password" name="code" maxlength="18" placeholder="请输入您的密码" v-model="pwd" />
					</view>
					<view class="wjmm">
						<!-- 忘记密码？ -->
						
					</view>
					<button :class="leaveClass" v-show="ifLogin" @tap="register()">注 册</button>
	
				</form>
				<view class="t-f"><text>—————— 第三方账号登录 ——————</text></view>
				<view class="t-e cl">
					<!-- <view class="t-g" @tap="wxLogin()">
						<image src="../../../static/my/wx.png"></image>
					</view>
					<view class="t-g" @tap="qqLogin()">
						<image src="../../../static/my/qq.png"></image>
					</view> -->
				</view>
			</view>
		</view>
		<loading
		    ref="loading"
		    :custom="false"
		    :shadeClick="true"
		    :type="1"
		    @callback="callback()">
		        <!-- <view class="test">自定义</view> -->
		</loading>
	</view>
</template>

<script>

	import loading from '../../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				phone: '', //账号
				pwd: '', //密码,
				yz:'',//验证点没点验证码
				yzm: 'yzm0', //验证码,
				ifLogin: true,
				// animate__animated animate__backOutLeft
				leaveClass: "",
				time:"获取验证码",
				check: false
			};
		},
		components: {
			loading
		},
		methods: {
			//动画
			close:function(){
			    this.$refs.loading.close();
			},
			open:function(){
			    this.$refs.loading.open();
			},
			callback(){
			    //console.log("回掉");
			},
			
			
			//切换到登录
			reg(){
				uni.redirectTo({
					url:'../login/login'
				})
			},
			//获取验证码
			getYzm(){
				this.check = true
				// //console.log("获取验证码！")
				if(this.time === '获取验证码'){
					this.yzm = 'yzm1'
					this.time = 60
					var a = setInterval(() => {
						this.time--
						if(this.time <= 0){
							clearInterval(a);
							this.yzm = 'yzm0'
							this.time = '获取验证码'
						}
					},1000);
				}
				
			},
			
			//注册点击
			register(){
				
				//console.log('注册')
					var that = this;
					if (that.phone.length != 11) {
						uni.showToast({
							title: '请输入正确的手机号',
							icon: 'none'
						});
						return;
					}
					
					// if (!that.yz) {
					// 	uni.showToast({
					// 		title: '请输入验证码',
					// 		icon: 'none'
					// 	});
					// 	return;
					// }
					
					if (!that.pwd) {
						uni.showToast({
							title: '请输入您的密码',
							icon: 'none'
						});
						return;
					}
					// if(!this.check){
					// 	//console.log('没点验证码！')
					// 	uni.showToast({
					// 		title:'请先获取验证码！',
					// 		icon:'none'
					// 	})
					// 	return;
					// }
					this.open()
					// //console.log('这是验证',this.yz)
					//新的密码
					var newCookey = 'y' + this.pwd + 'l' + this.phone + 'h.z'

					
					// newCookey = md5(newCookey)
					// 加密
					newCookey = this.$encryptDes(newCookey)
					//console.log(newCookey)
					// 注册
					var userid = Number(this.phone);
					var data = {
							"userid": userid,
							'userkey':newCookey
						}
					const register = this.$myRequest({
						url : '/userRegister',
						method : 'post',
						data : data
					})
					register.then((res) => {
						this.close()
						uni.showToast({
							title:res.result.res,
							icon:"none"
						})
						if(res.status === 1){
							setTimeout( () => {
								this.reg()
							},2000)
						}
					})
			}
		}
	}
</script>

<style scoped>
	.yzm0{
		color: #007AFF;
	}
	.yzm1{
		color: #8c8c8c;
	}
	
.topClass {
		width: 85%;
		margin-left: auto;
		margin-right: auto;
		height: 360upx;
		/* background-color: #007AFF; */
		display: flex;
		justify-content: flex-end;
		flex-direction: column;
	}

	.bigTitle {
		/* height: 100upx; */
		font-size: 60upx;
		font-weight: 700;
	}

	.smailTitle {
		color: #5B5B5B;
		font-size: 33upx;
	}

	.wjmm {
		font-size: 20upx;
		font-weight: 800;
		height: 30upx;
		margin-top: -25upx;
		margin-bottom: 60upx;
		/* color: #007AFF; */
	}

	.ty {
		text-align: center;
		margin-top: 20upx;
	}


	.txt {
		font-size: 32rpx;
		font-weight: bold;
		color: #333333;
	}

	.img-a {
		width: 100%;
		height: 450rpx;
		background-image: url(../../../static/my/head.png);
		background-size: 100%;
	}

	.reg {
		font-size: 28rpx;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
		background: #f5f6fa;
		color: #000000;
		text-align: center;
		margin-top: 30rpx;
	}

	.login-view {
		width: 100%;
		position: relative;

		background-color: #ffffff;
		border-radius: 8% 8% 0% 0;
	}

	.t-login {
		width: 85%;
		margin: 0 auto;
		font-size: 28rpx;
		padding-top: 60upx;
	}

	.t-login button {
		font-size: 28rpx;
		background: #2796f2;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
	}

	.t-login input {
		height: 90rpx;
		line-height: 90rpx;
		margin-bottom: 50rpx;
		border-bottom: 1px solid #e9e9e9;
		font-size: 28rpx;

	}

	.t-login .t-a {
		position: relative;
	}

	.t-b {
		text-align: left;
		font-size: 42rpx;
		color: #ffffff;
		padding: 130rpx 0 0 70rpx;
		font-weight: bold;
		line-height: 70rpx;
	}

	.t-login .t-c {
		position: absolute;
		right: 22rpx;
		top: 22rpx;
		background: #5677fc;
		color: #fff;
		font-size: 24rpx;
		border-radius: 50rpx;
		height: 50rpx;
		line-height: 50rpx;
		padding: 0 25rpx;
	}

	.t-login .t-d {
		text-align: center;
		color: #999;
		margin: 80rpx 0;
	}

	.t-login .t-e {
		text-align: center;
		width: 250rpx;
		margin: 80rpx auto 0;
	}

	.t-login .t-g {
		float: left;
		width: 50%;
	}

	.t-login .t-e image {
		width: 50rpx;
		height: 50rpx;
	}

	.t-login .t-f {
		text-align: center;
		margin: 30upx 0 0 0;
		color: #666;
	}

	.t-login .t-f text {
		margin-left: 20rpx;
		color: #aaaaaa;
		font-size: 27rpx;
	}

	.t-login .uni-input-placeholder {
		color: #aeaeae;
	}

	.cl {
		zoom: 1;
	}

	.cl:after {
		clear: both;
		display: block;
		visibility: hidden;
		height: 0;
		content: '\20';
	}
</style>
