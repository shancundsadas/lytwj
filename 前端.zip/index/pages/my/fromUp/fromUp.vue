<template>
	<view>
		<view class="fromUp_0">
			<view class="fromUp_0_text">
				1.姓名
			</view>
			<input type="text" value="" placeholder="输入名字" v-model="myData.name" />
		</view>

		<view class="fromUp_0" @click="mySex">
			<view class="fromUp_0_text">
				2.性别
			</view>
			<view class="sex">
				{{ myData.sex | makeSex}}
			</view>
		</view>

		<view class="fromUp_0">
			<view class="fromUp_0_text">
				3.联系方式
			</view>
			<input type="number" value="" placeholder="输入联系方式" v-model="myData.phone" />
		</view>

		<view class="fromUp_0">
			<view class="fromUp_0_text">
				4.身份证号
			</view>
			<input type="text" value="" placeholder="输入身份证号" v-model="myData.idNumber" />
		</view>

		<view class="fromUp_0">
			<view class="fromUp_0_text">
				5.家庭住址
			</view>
			<input type="text" value="" placeholder="输入家庭住址" v-model="myData.userAdress" />
		</view>


		<view class="fromUp_but" @click="saveData">
			保存信息
		</view>
		
		
		<loading
		    ref="loading"
		    :custom="false"
		    :shadeClick="true"
		    :type="1">
		        <!-- <view class="test">自定义</view> -->
		</loading>
		
	</view>
</template>

<script>
	import loading from '../../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				myData: {
					name: '',
					sex: '请输入性别',
					userAdress: '',
					idNumber: '',
					phone: ''
				}
			}
		},
		components: {
			loading
		},
		onLoad() {
			const userData = uni.getStorageSync('ZXCW_USERDATA');
			console.log('当前用户',userData)
			this.getUserData()
		},
		filters: {
			makeSex(value) {
				console.log('这里是啥？',value)
				if (value === 0) {
					return '女'
				} else if (value === 1) {
					return '男'
				}else{
					return '请输入性别'
				}
				
			}
		},
		methods: {
			
			//动画
			close:function(){
			    this.$refs.loading.close();
			},
			open:function(){
			    this.$refs.loading.open();
			},
			// 获取用户的基本信息
			getUserData() {
				var token = uni.getStorageSync('ZXCW_USERMAIN');
				const userData = uni.getStorageSync('ZXCW_USERDATA');
				var token = this.$decryptDes(token)
				const r = this.$myRequest({
					url: '/getMyData',
					method: 'post',
					data: {
						userid: userData.user_id,
						userMain: token
					}
				})
				r.then(res => {
					console.log(res.result.res[0])
					this.myData.name = res.result.res[0].name
					this.myData.sex = res.result.res[0].sex
					this.myData.phone = res.result.res[0].phone
					this.myData.idNumber = res.result.res[0].idNumber
					this.myData.userAdress = res.result.res[0].userAdress
				})
			},
			// 性别输入
			mySex() {
				console.log('你好')
				uni.showActionSheet({
					itemList: ['女', '男'],
					success: (res) => {
						switch (res.tapIndex) {
							case 0:
								this.myData.sex = 0
								break
							case 1:
								this.myData.sex = 1
								break
						}
					}
				})
			},
			// 保存信息
			saveData() {
				// 拦截器
				if (this.myData.name === '') {
					uni.showToast({
						title: '请填写姓名',
						icon: 'none'
					})
					return
				}

				if (this.myData.sex === null || this.myData.sex === '') {
					uni.showToast({
						title: '请填写性别',
						icon: 'none'
					})
					return
				}
				
				if (this.myData.phone === null || this.myData.phone === '') {
					uni.showToast({
						title: '请填写手机号',
						icon: 'none'
					})
					return
				}
				
				if (this.myData.idNumber === null || this.myData.idNumber === '') {
					uni.showToast({
						title: '请输入身份证号',
						icon: 'none'
					})
					return
				}
				if (this.myData.userAdress === null || this.myData.userAdress === '') {
					uni.showToast({
						title: '请输入家庭住址',
						icon: 'none'
					})
					return
				}
				this.$refs.loading.open();
				var token = uni.getStorageSync('ZXCW_USERMAIN');
				const userData = uni.getStorageSync('ZXCW_USERDATA');
				var token = this.$decryptDes(token)
				this.myData.userMain = token
				this.myData.userid = userData.user_id
				
				const r = this.$myRequest({
					url: '/upUserData',
					method: 'post',
					data: this.myData
				})
				r.then(res => {
					console.log(res)
					if(res.status === 1){
						const userData = uni.getStorageSync('ZXCW_USERDATA');
						console.log('当前用户',userData)
						uni.setStorage({
						    key: 'ZXCW_USERDATA',
						    data: {
								user_id : userData.user_id,
								user_name : this.myData.name,
								ifData : 1,
								ifBind : userData.ifBind
							},
						    success:  (res) => {
						        console.log('success');
								this.$refs.loading.close();
								uni.showToast({
									title:'修改成功'
								})
								setTimeout( () => {
									uni.switchTab({
										url: '/pages/index/index'
									});
								},1000)
						    }
						});
					}
					
				})
			},


		}
	}
</script>

<style scoped>
	.fromUp_0 {
		display: flex;
		width: 95%;
		height: 110upx;
		justify-content: space-between;
		align-items: center;
		margin: 0 auto 0 auto;
		border-bottom: 1px solid #f0f0f0;
	}

	.fromUp_0_text {
		font-size: 30upx;
		font-weight: 700;
	}

	.fromUp_0 input {
		/* background-color: #000000; */
		width: 340upx;
		height: 100%;
		text-align: right;
	}

	.fromUp_1 {
		width: 95%;
		height: 260upx;
		margin: 0 auto 0 auto;
		display: flex;
		flex-direction: column;
		justify-content: space-evenly;
		border-bottom: 1px solid #dedede;
	}

	.fromUp_1 image {
		width: 150upx;
		height: 150upx;
		margin-left: 10upx;
	}

	.fromUp_but {
		
		height: 83upx;
		width: 250upx;
		background: linear-gradient(to right, #4e71e5, #789fe7);
		color: #ffffff;
		border-radius: 15upx;
		margin: 500upx auto 0 auto;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 30upx;
		font-weight: 700;
	}

	.sex {
		font-size: 33upx;
		color: #7a7a7a;
	}
</style>
