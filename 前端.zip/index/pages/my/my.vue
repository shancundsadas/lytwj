<template>
	<view style="background-color: #f6f6f6; height: 100%;">
		<view class="myTop">
			<view style="width: 100%;height: 70upx;"></view>
			<view class="myTop_top">
				<image src="../../static/my/sz.png" mode="" @click="sz"></image>
			</view>

			<view class="myTop_bottom_image">
				<image src="../../static/my/me.png" mode=""></image>
			</view>

			<view class="myTop_bottom_text" @click="goLogin">
				<view class="my_top_bottom_text_top">
					{{ name }}
				</view>
				<view class="my_top_bottom_text_bottom">

				</view>
			</view>
			<!-- <view class="myTop_bottom_jc">
					<view class="" style="margin-bottom: 20upx;">
						<image src="../../static/dh.png" mode=""></image>
						<P>已填写必要信息</P>
					</view>
					<view class="">
						<image src="../../static/gth.png" mode=""></image>
						<P>未绑定蓝牙设备</P>
					</view>
				</view> -->

		</view>
		<view class="myMidel" @click="makeZt" v-show="ztShow">
			<view class="myMidel_left">
				{{ oldTime | day }}
			</view>
			<view class="myMidel_right">
				<view class="myMidel_right_top">
					<p class="zhuangtaiYanSe">{{ zt }}</p>
					{{ address1 }}
				</view>
				<view class="myMidel_right_bottom">
					{{ oldTime | time }}
				</view>
			</view>
		</view>


		<view class="myBottom">
			<view class="myBottom_but" @click="goFromUp">
				<p>填写信息</p>
				<image src="../../static/jt.png" mode=""></image>
			</view>
			<!-- 地址选择器 -->
			<pickerAddress @change="change" v-show="ifChange">
				<view class="myBottom_but">
					<p>填写隔离点</p>
					<image src="../../static/jt.png" mode=""></image>
				</view>
			</pickerAddress>

		</view>
		<view>

			<neil-modal :show="show4" @close="closeModal('4')" title=" " @cancel="bindBtn('cancel')"
				@confirm="bindBtn('confirm')">
				<view class="input-view">
					<view class="input-name">
						<view style="font-size: 25upx;">详细地址:</view>
						<input type="text" placeholder="如**小区3号楼201" v-model="address" />
					</view>
				</view>
			</neil-modal>


		</view>
	</view>
</template>

<script>
	import neilModal from '@/components/neil-modal/neil-modal.vue';
	import pickerAddress from '../../components/pickerAddress.vue' //引入地址选择器组件

	export default {
		data() {
			return {
				show4: false,
				address0: '请输入地址',
				address: '',
				address1: '请输入地址',
				oldTime: '',
				zt: '',
				ztShow: false,
				name: '未登录',
				ifChange : false
			}
		},
		components: {
			neilModal,
			pickerAddress
		},
		onLoad() {

		},
		filters: {
			time(value) {
				if (value === '') {
					return value
				}
				var time = new Date(parseInt(value))
				return time.getFullYear() + '/' + (time.getMonth() + 1) + '/' + time.getDate() + '  ' + time.getHours() +
					':' + time.getMinutes() + ":" + time.getSeconds()
				// return '隔离时间：' + value
			},
			//隔离第几天
			day(value) {
				if (value === '') {
					return value
				}
				let newTime = new Date()
				let sDate1 = new Date(value)
				let sDate2 = newTime
				var dateSpan,
					tempDate,
					iDays;
				sDate1 = Date.parse(sDate1);
				sDate2 = Date.parse(sDate2);
				dateSpan = sDate2 - sDate1;
				dateSpan = Math.abs(dateSpan);
				iDays = Math.floor(dateSpan / (24 * 3600 * 1000));
				return '第' + (iDays + 1) + '天'
			},

		},
		watch: {

		},
		onShow() {
			this.ifLogin()
			this.gl()
		},
		methods: {

			// 加载展示 是否登录
			ifLogin() {
				// 获取一下token 户然 用户名
				const token = uni.getStorageSync('ZXCW_USERMAIN');

				if (token) {
					// 已经登陆
					var userData = uni.getStorageSync('ZXCW_USERDATA');
					this.ifChange = true
					this.name = userData.user_id
				} else {
					this.ifChange = false
					this.name = '未登录'
				}

			},
			//点击了设置
			sz() {
				//点击了设置
				uni.showActionSheet({
					itemList: ['注销登录','清除隔离状态'],
					success: (res) => {
						// //console.log('选中了第' + (res.tapIndex + 1) + '个按钮');
						switch (res.tapIndex) {
							case 0:
								console.log("点击了注销登录")
								uni.removeStorageSync('ZXCW_USERMAIN');
								uni.removeStorageSync('ZXCW_USERDATA');
								uni.removeStorageSync('ZXCW_GLXX');
								this.ifLogin()
								this.gl()
								break
								case 1:
									console.log("点击了1")
									uni.removeStorageSync('ZXCW_GLXX');
								break
								// case 2:
								// 	//console.log("点击了2")
								// 	break
						}
					},
					fail: function(res) {
						//console.log(res.errMsg);
					}
				})
			},

			//点击当前状态 切换
			makeZt() {
				console.log('点击切换状态')
			},
			//跳转到表单填写
			goFromUp() {
				const token = uni.getStorageSync('ZXCW_USERMAIN');
				if (!token) {
					this.goLogin()
					
				}else{
					uni.navigateTo({
						url: 'fromUp/fromUp'
					})
				}
				
			},
			goLogin() {
				const token = uni.getStorageSync('ZXCW_USERMAIN');
				if (token) {
					return
				}
				uni.navigateTo({
					url: './login/login'
				})
			},
			/* 
			..1.弹出框 
			 
			 */
			bindClick(type) {
				console.log(this[`show${type}`])
				this[`show${type}`] = true
				console.log(this[`show${type}`])
			},
			closeModal(type) {
				console.log(`监听到close`)
				this[`show${type}`] = false
			},
			bindBtn(type) {
				// uni.showToast({
				//     title: `点击了${type==='cancel'?'取消':'确定'}按钮`,
				//     icon: 'none'
				// })
				// console.log(type)
				if (type === 'cancel') {
					//点击了取消
					console.log('点击了取消')
				} else {
					console.log('点击了确定')
					if (this.address === '') {
						uni.showToast({
							title: '请填写详细信息',
							icon: 'none'
						})
						return
					}
					var glData = {
						address1: this.address0 + this.address,
						getOldTime: new Date().getTime(),
						zt: "（隔离中）",
						ztShow: true
					}
					// 存储信息
					uni.setStorage({
						key: 'ZXCW_GLXX',
						data: glData,
						success: () => {
							console.log('success');
						}
					});
					this.gl()
				}
			},
			// 隔离信息
			gl() {
				const glData = uni.getStorageSync('ZXCW_GLXX');
				if (glData) {
					// console.log('隔离信息', glData)
					this.address1 = glData.address1
					this.oldTime = glData.getOldTime
					this.zt = glData.zt
					this.ztShow = glData.ztShow
				}else{
					this.ztShow = false
				}

			},

			//改变地址
			change(data) {
				const token = uni.getStorageSync('ZXCW_USERMAIN');
				if (!token) {
					this.goLogin()
					
				}else{
					this.address0 = data.data.join('')
					this.bindClick('4')
				}
			},
			//获取当前时间戳
			getOldTime() {
				let timestamp = new Date().getTime()
				console.log('当前时间戳', timestamp)
				
			},

		}
	}
</script>

<style scoped>
	.myTop {
		width: 100%;
		height: 650upx;
		/* background-color: #5379f5; */
		background: linear-gradient(to right, #4e71e5, #789fe7);
		border-bottom-left-radius: 55upx;
		border-bottom-right-radius: 55upx;
	}

	.myTop_top {
		width: 100%;
		height: 80upx;
		display: flex;
		justify-content: flex-end;
	}

	.myTop_top image {
		width: 50upx;
		height: 50upx;
		margin-right: 40upx;
	}

	.myTop_bottom image {
		width: 215upx;
		height: 215upx;
		border-radius: 50%;
		/* margin-left: 50upx; */
	}

	.myTop_bottom_text {
		width: 250upx;
		margin: 40upx auto 0 auto;
		color: #a1e9fd;
	}


	.myTop_bottom_image {
		width: 215upx;
		height: 215upx;
		margin: 0 auto 0 auto;
		/* margin-bottom: 40upx; */
	}

	.myTop_bottom_image image {
		width: 100%;
		height: 100%;
		border-radius: 50%;

	}

	.myTop_bottom_text view {
		display: flex;
		align-items: center;
		justify-content: center;
		color: #f5f5f5;
	}

	.my_top_bottom_text_top {
		font-weight: 700;
		font-size: 45upx;
	}

	.my_top_bottom_text_bottom {
		font-size: 28upx;
		color: #676767;
	}

	.myTop_bottom_jc {
		margin-left: 5upx;
	}

	.myTop_bottom_jc image {
		width: 30upx;
		height: 30upx;
	}

	.myTop_bottom_jc view {
		display: flex;
		font-size: 20upx;
		color: #565354;
		align-items: center;
	}

	.myTop_bottom_jc p {
		margin-left: 15upx;
	}

	/* 
	 */
	/* 隔离 */
	.myMidel {
		width: 700upx;
		height: 200upx;
		margin: -80upx auto 0 auto;
		border-radius: 15upx;
		background-color: #ffffff;
		display: flex;
		box-shadow: 0px 0px 20px #8cb0e5;
	}

	/* 确诊 */
	.myMidel0 {
		width: 95%;
		height: 200upx;
		margin: 20upx auto 0 auto;
		border-radius: 15upx;
		background-color: #EF476F;
		display: flex;
	}

	/* 健康 */
	.myMidel1 {
		width: 95%;
		height: 200upx;
		margin: 20upx auto 0 auto;
		border-radius: 15upx;
		background-color: #06D6A0;
		display: flex;
	}

	.myMidel_left {
		width: 200upx;
		height: 180upx;
		/* background-color: #007AFF; */
		margin-top: 10upx;
		font-size: 60upx;
		font-weight: 700;
		color: #073B4C;
		display: flex;
		align-items: center;
		justify-content: center;
		border-right: 1px solid #dbdfc2;
	}

	.myMidel_right {
		width: 450upx;
		height: 200upx;
		margin-left: 10upx;
		display: flex;
		flex-direction: column;

		/* justify-content: center; */
		justify-content: space-around;
	}

	.myMidel_right_top {
		font-size: 35upx;
		font-weight: 700;
		margin: 0 auto 0 auto;
		height: 120upx;
		overflow-x: hidden;
		overflow-y: scroll;
		width: 100%;
		color: #073B4C;
	}

	.zhuangtaiYanSe {
		display: inline;
		color: #fff182;
	}

	.myMidel_right_bottom {
		font-size: 25upx;
		color: #828282;
		font-weight: 700;

	}

	/*  */
	.myBottom {
		width: 95%;
		margin: 50upx auto 0 auto;
		background-color: #fafafa;
	}

	.myBottom_but {
		display: flex;
		height: 94upx;
		width: 100%;
		/* background-color: #007AFF; */
		align-items: center;
		justify-content: space-between;
		border-bottom: 1px solid #f6f6f6;
	}

	.myBottom_but p {
		font-size: 32upx;
		/* font-weight: 700; */
		margin-left: 20upx;
		color: #717171;
	}

	.myBottom_but image {
		width: 35upx;
		height: 35upx;
		margin-right: 20upx;
	}

	.input-name {
		/* height: 200upx; */
		height: 80upx;
		width: 100%;
		display: flex;
	}

	.input-name view {
		font-size: 35upx;
		margin-left: 20upx;
		font-weight: 700;
	}

	.input-name input {
		width: 350upx;
		margin-left: 55upx;
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: center;
		position: relative;
		padding-left: 30upx;
		box-sizing: border-box;
		/* background-color: #000000; */
	}
</style>
