<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	/* 引入全局官方css */
	@import "/common/uni.css";
	/* 引入第三方动画库 */
	@import "/common/animate.min.css";
	/* 引入图标库 */
	@import "/common/icon.css";
	/* 引入全局样式 */
	@import "/common/common.css";
</style>
