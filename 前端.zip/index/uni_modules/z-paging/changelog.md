## 2.0.8（2021-10-14）
1.修复`ReferenceError: getPrivateLanguage is not defined`报错的问题  
2.修复在nvue中使用聊天记录模式时，手动调用`scrollToTop`或`scrollToBottom`时递归调用的问题。  
3.修复使用`u-grid`时，内部item元素过多时。`z-paging`自定义的下拉刷新view与默认下拉刷新view同时展示的问题。
## 2.0.7（2021-10-08）
1.修复在一些平台中，底部加载更多会被遮挡的问题。  
2.修复在nvue中`safe-area-inset-bottom`为true时，可能出现的顶部异常偏移的问题。  
3.修复在HbuilderX 3.2.8+中，下拉刷新时@onRefresh被触发多次的问题。  
4.修复在iOS中滚动到顶部view，在某些情况下因bounce的影响闪一下又消失的问题。  
5.修复在使用页面滚动时，滚动到顶部view未能正常显示的问题。  
6.修复在nvue中，使用聊天记录模式，数据未满一页时，数组被颠倒的问题。  
7.修复在nvue中，使用页面滚动时，`scrollToTop`无效的问题。  
8.修复在nvue中，使用聊天记录模式时，`scrollToBottom`和`scrollToTop`效果颠倒的问题。  
9.修复在安卓 nvue中，导航栏与z-paging间出现的白色分割线的问题。  
10.修复在HbuilderX 3.2.9+中，vue下拉刷新加载中时有一段空白间隙的问题。
