
import CryptoJS from '../node_modules/crypto-js/crypto-js.js'
 
// DES加密
export const encryptDes = (code) => {
	var c=String.fromCharCode(code.charCodeAt(0)+code.length);
	    for(var i=1;i<code.length;i++){
	        c+=String.fromCharCode(code.charCodeAt(i)+code.charCodeAt(i-1));
	    }
	    return(escape(c));
}

export const decryptDes = (code) => {
	code=unescape(code);
	    var c=String.fromCharCode(code.charCodeAt(0)-code.length);
	    for(var i=1;i<code.length;i++){
	        c+=String.fromCharCode(code.charCodeAt(i)-c.charCodeAt(i-1));
	    }
	    return c;
}

// export const encryptDes = (message, key) => {
//   const keyHex = CryptoJS.enc.Utf8.parse(key);
//   const encrypted = CryptoJS.DES.encrypt(message, keyHex, {
//    mode: CryptoJS.mode.ECB,
//    padding: CryptoJS.pad.Pkcs7
//    });
//   return encrypted.toString();
// }
 
// // DES解密
// export const decryptDes = (ciphertext, key) => {
//   const keyHex = CryptoJS.enc.Utf8.parse(key);
//   // direct decrypt ciphertext
//   const decrypted = CryptoJS.DES.decrypt({
//      ciphertext: CryptoJS.enc.Base64.parse(ciphertext)
//    }, keyHex, {
//      mode: CryptoJS.mode.ECB,
//      padding: CryptoJS.pad.Pkcs7
//   });
//   console.log('解密失败？',keyHex)
//   return decrypted.toString(CryptoJS.enc.Utf8);
// }
