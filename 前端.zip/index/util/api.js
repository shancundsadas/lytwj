// const  BASE_URL = "http://127.0.0.1:1620/public/index.php/index"
const  BASE_URL = "http://159.75.138.69:9651/public/index.php/index"

// 封装好  ajax
export const myRequest = (option) =>{
	return new Promise((resolve,reject)=>{
		uni.request({
			url:BASE_URL+option.url,
			method:option.method || "post",   //如果没有就是get
			data: option.data || "",
			success: (res) => {
				// //console.log(res)
				resolve(res.data)
			},
			fail: (err) => {
				uni.showToast({
					title:"获取数据失败,请检查网络！",
					icon: 'error'
				})
				reject(err)
			}
		})
	})
}
