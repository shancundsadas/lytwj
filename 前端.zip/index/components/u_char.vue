<template>
	<view class="charts-box">
		<qiun-data-charts type="line" :chartData="chartData" :loadingType="1" background="none" :ontouch="true" />
	</view>
</template>

<script>
	export default {
		name: "u_char",
		data() {
			return {
				"categories": [
					"2016",
					"2017",
					"2018",
					"2019",
					"2020",
					"2016",
					"2017",
					"2018",
					"2019",
					"2020",
					"2021"
				],
				"series": [{
						"name": "成交量A",
						"data": [
							35,
							8,
							25,
							37,
							4,
							20
						]
					},
					{
						"name": "成交量B",
						"data": [
							70,
							40,
							65,
							100,
							44,
							68
						]
					},
					{
						"name": "成交量C",
						"data": [
							100,
							80,
							95,
							150,
							112,
							132
						]
					}
				]
			};
		}
	}
</script>

<style>

</style>
