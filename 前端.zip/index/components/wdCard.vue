<template>
	
	<view class="wdDtCard">
		<view class="card_all">
			<view class="card_top">
				<image :src="'https://api.ixiaowai.cn/gqapi/gqapi.php?id='+id" mode="widthFix"></image>
			</view>
			 <view class="card_text">
			 	<view :class="'card_text_left '+' '+color">
			 		{{ wdDatas.temperature }}
			 	</view>
				<view class="card_text_right">
					<view class="card_text_top">
						{{ wdDatas.adress }}
					</view>
					<view class="card_text_bottom">
						{{ wdDatas.time | time }}
					</view>
				</view>
			 </view>
		</view>
	</view>
	
</template>

<script>
	export default {
		name:"wdCard",
		data() {
			return {
				color : 'color0'
			}
		},
		props:["id","wdDatas"],
		mounted() {
			this.changeColor()
		},
		filters:{
			time(value){
				value = parseInt(value) * 1000
				var oldTime = new Date(value)
				return oldTime.getFullYear() + '/' + (oldTime.getMonth()+1) + '/' + oldTime.getDate() + ' ' + oldTime.getHours() + ':' + oldTime.getMinutes() 
			}
		},
		methods:{
			//判断提问展示的颜色
			changeColor(){
				if(this.wdDatas.temperature > 37.3){
					console.log(this.color)
					this.color = 'color1'
				}else if(this.wdDatas.temperature < 36){
					this.color = 'color2'
				}
			}
			
		},
		
	}
</script>

<style scoped>
.wdDtCard{
		border-top: 1px solid #f8f8f8;
		width: 95%;
		height: 550upx;
		margin: 0 auto 0 auto;
		background-color: #f8f8f8;
		
	}
	.card_all{
		width: 95%;
		height: 90%;
		margin: 5% auto auto auto;
		border-radius: 8upx;
		/* background-color: #0088CC; */
	}
	.card_top{
		width: 100%;
		height: 350upx;
		overflow: hidden;
	}
	.card_top image{
		border-top-left-radius:15upx ;
		border-top-right-radius: 15upx;
		width: 100%;
		height: 100%;
		
	}
	.card_text{
		width: 100%;
		height: 30%;
		background-color: #ffffff;
		display: flex;
		border-bottom-left-radius: 15upx;
		border-bottom-right-radius: 15upx;
		
	}
	.card_text_left{
		width: 200upx;
		height: 100%;
		/* background-color: #007AFF; */
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 700;
		font-size: 70upx;
	}
	.card_text_right{
		width: 450upx;
		height: 100%;
		display: flex;
		flex-direction: column;	
		justify-content: center;
		/* background-color: #007AFF; */
	}
	.card_text_top{
		font-size: 30upx;
		font-weight: 700;
		margin-top: 12upx;
		display: flex;
		/* align-items: center; */
		height: 97upx;
		overflow:auto;
	}
	.card_text_bottom{
		font-size: 25upx;
		/* margin-top: 5upx; */
		color: #c5c5c5;
	}
	.color0{
		color: #1fa736;
	}
	.color1{
		color: #ff0000;
	}
	.color2{
		color: #2468a7;
	}
</style>
