import App from './App'

// #ifndef VUE3
import Vue from 'vue'

//引入封装的方法
import { myRequest } from './util/api.js'

// 加密解密
import { encryptDes, decryptDes  } from './util/des.js.js' // 引用路径根据自己的文件结构而定

// encryptDes('要加密的数据', '加密的key')

// decryptDes('要解密的数据', '解密的key') 


// 二次封装  ajax
Vue.prototype.$myRequest = myRequest;
// 加密
Vue.prototype.$encryptDes = encryptDes
// 解密
Vue.prototype.$decryptDes = decryptDes


Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif
/*
 * @Author: your name
 * @Date: 2021-08-07 18:35:50
 * @LastEditTime: 2021-08-08 15:20:14
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \active-form demo\main.js
 */
// import Vue from 'vue'
// import App from './App'

// // //引入封装的方法
// import { myRequest } from './util/api.js'

// // // 二次封装  ajax
// Vue.prototype.$myRequest = myRequest;
// Vue.config.productionTip = false

// Vue.use(verification)
// App.mpType = 'app'

// const app = new Vue({
//     ...App
// })
// app.$mount()