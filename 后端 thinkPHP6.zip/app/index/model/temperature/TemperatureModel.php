<?php

namespace app\index\model\temperature;

use think\Model;

class TemperatureModel extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'zxcw_tw';
//    保存温度
    public function addTemperatureDemo($arr){
        return $this->save($arr);
    }
//    查询 用户的体温记录
    public function getTimestamp($userid,$page)
    {
        return $this->where('user_id',$userid)->order('time desc')->paginate([
            'list_rows'=> 10,//一次查多少
            'var_page' => 'page',
            'page' => $page
        ]);
    }
//    删除用户监测信息表
    public function delUserTem($userid)
    {
        return $this->where('user_id', $userid)->delete();
    }
//    查询全部用户上传的温度
    public function getAllTimestamp($page)
    {
        return $this->order('time desc')->paginate([
            'list_rows'=> 10,//一次查多少
            'var_page' => 'page',
            'page' => $page
        ]);
    }
//    查询今日的 全部温度表
    public function getAllTimestampTy($page)
    {
        $time = time();
        $now_date= date('Y-m-d',$time);
        return $this->where('time1',$now_date)->order('time desc')->paginate([
            'list_rows'=> 10,//一次查多少
            'var_page' => 'page',
            'page' => $page
        ]);
    }
//    getTemNote 获取今日体温异常
    public function getTemNote($page)
    {
        $time = time();
        $now_date= date('Y-m-d',$time);
        return $this->where('time1',$now_date)->where('temperature','>',37.3)->order('time desc')->paginate([
            'list_rows'=> 10,//一次查多少
            'var_page' => 'page',
            'page' => $page
        ]);
    }


}