<?php

namespace app\index\model\user;
use think\Model;
class UserDataModel extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'zxcw_user_data';
    //添加用户信息
    public function addUserData($arr){
        return $this->save($arr);
    }
    //查出用户主要信息
    public function getSomeUserData($userid){
        return $this->where('user_id',$userid)->field('user_id,name,userAdress,idNumber,phone,sex,ifBind,ifData,today_first,today_second')->select();
    }

    //更新用户绑定信息
    public function upUserData($userid,$dataArr)
    {
        return $this->where('user_id', $userid)->update($dataArr);
    }

//    查看用户全部信息
    public function getAllData($page)
    {
        return $this->paginate([
            'list_rows'=> 10,//一次查多少
            'var_page' => 'page',
            'page' => $page
        ]);
    }

//    删除用户信息
    public function delUserData($userid)
    {
        return $this->where('user_id',$userid)->delete();
    }

    //    查看今日第几次测温
    public function todayCw($userid,$wd){
        $newtime = time();
        $time = (int)date('H',$newtime);
        if( 0 <= $time && $time <= 12){
//            中午
           return $this->where('user_id', $userid)->update(['today_first'=>$wd]);
        }elseif(13 <= $time && $time <= 23){
//            下午
            return $this->where('user_id', $userid)->update(['today_second'=>$wd]);
        }
        return 0;
    }
    //    检查是否已经被绑定
    public function getBinded($macId){
        return $this->where('ifBind',$macId)->select();
    }
}