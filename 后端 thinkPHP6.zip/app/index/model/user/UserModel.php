<?php

namespace app\index\model\user;
use think\Model;
class UserModel extends Model
{
// 设置当前模型对应的完整数据表名称
    protected $table = 'zxcw_user';

    //查询是否已经有此id
    public function getUserId($userid){
        return $this->where('user_id', $userid)->find();
    }

    //创建用户
    public function saveUser($userid,$userkey,$secret){
        return $this->save([
            'user_id'=>$userid,
            'user_key'=>$userkey,
            'secret'=>$secret,
            'jurisdiction' => 0
        ]);
    }
}