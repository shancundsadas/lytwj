<?php

namespace app\index;
//处理用户token
use app\index\model\user\UserModel;

class CommonFun
{
    //用户身份验证 0代表没有帐户 1代表成功 2代表密码错误
    public function UserIf($userid,$userkey){
        $user = new UserModel();
        $results = $user->getUserId($userid);
        if(empty($results)){
            return 0;
            //没有帐户
        }else{
            //有账户
            $key = $results->secret;
            $arr = str_split($key,2);
            $userKey = $arr[1].$userid.$arr[2].$userkey.$arr[0];
            $userKey = md5($userKey);
            if($results->user_key == $userKey){
                //验证成功
                return 1;
            }else{
                return 2;
            }
        }
    }
//    用户token验证
    public function UserToken($userid,$token){
        $res = $this->unlock_url($token);
        $nowUserId = explode("%",$res);
        if($nowUserId[0] == $userid){
//            1表示验证成功
            return 1;
        }
        return 0;
    }

//    生成用户Token
    public function makeToken($userid,$userKey){
//        通过加密函数生成Token
        return $this->lock_url($userid.'%'.$userKey);
    }

//加密函数
    function lock_url($txt,$key='str'){
        $txt = $txt.$key;
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-=+";
        $nh = rand(0,64);
        $ch = $chars[$nh];
        $mdKey = md5($key.$ch);
        $mdKey = substr($mdKey,$nh%8, $nh%8+7);
        $txt = base64_encode($txt);
        $tmp = '';
        $i=0;$j=0;$k = 0;
        for ($i=0; $i<strlen($txt); $i++) {
            $k = $k == strlen($mdKey) ? 0 : $k;
            $j = ($nh+strpos($chars,$txt[$i])+ord($mdKey[$k++]))%64;
            $tmp .= $chars[$j];
        }
        return urlencode(base64_encode($ch.$tmp));
    }
//解密函数
    function unlock_url($txt,$key='str'){
        $txt = base64_decode(urldecode($txt));
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-=+";
        $ch = $txt[0];
        $nh = strpos($chars,$ch);
        $mdKey = md5($key.$ch);
        $mdKey = substr($mdKey,$nh%8, $nh%8+7);
        $txt = substr($txt,1);
        $tmp = '';
        $i=0;$j=0; $k = 0;
        for ($i=0; $i<strlen($txt); $i++) {
            $k = $k == strlen($mdKey) ? 0 : $k;
            $j = strpos($chars,$txt[$i])-$nh - ord($mdKey[$k++]);
            while ($j<0) $j+=64;
            $tmp .= $chars[$j];
        }
        return trim(base64_decode($tmp),$key);
    }

}