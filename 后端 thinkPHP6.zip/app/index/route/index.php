<?php
use think\facade\Route;
//用户操作
//注册
//User 用户注册   userid  userkey
Route::post('userRegister','controller/User/userRegister')->allowCrossDomain();

//User 用户登录   userid  userkey
Route::post('userLogin','controller/User/userLogin')->allowCrossDomain();

//User 用户信息填写   userid  userMain name userAdress idNumber phone sex
Route::post('upUserData','controller/User/upUserData')->allowCrossDomain();

//判断是否已经被绑定   macId
Route::post('ifBinded','controller/Temperature/ifBinded')->allowCrossDomain();

//蓝牙绑定   userid  userMain
Route::post('upUserBind','controller/User/upUserBind')->allowCrossDomain();

//检测是否填写信息 和绑定蓝牙 userid userMain
Route::post('ifDataBind','controller/User/ifDataBind')->allowCrossDomain();

//上传温度 软件端口 userid userMain  temperature adress
Route::post('upTemperature','controller/Temperature/upTemperature')->allowCrossDomain();

//上传温度 硬件端口
Route::post('upTemperatureYj','controller/Temperature/upTemperatureYj')->allowCrossDomain();

//分页查询接口 userid userMain page
Route::post('getTemperature','controller/Temperature/getTemperature')->allowCrossDomain();

//获取用户详细信息 userid token
Route::post('getMyData','controller/User/getMyData')->allowCrossDomain();


