<?php
namespace app\ogjdhc\controller;

use app\BaseController;

class Index extends BaseController
{
    public function index()
    {
        return '创建成功！';
    }
}
