<?php

namespace app\index\controller;
use app\BaseController;
use app\index\business\temperature\TemperatureDemo;
use app\ogjdhc\CommonFun;

class Temperature extends BaseController
{
//    用户上传测温 软件端口
    public function upTemperature(){
        $user = $this->request->param();
        $demo = new TemperatureDemo();
//        获取当前时间戳
        $time = time();
        $arr = [
            'user_id' => $user['userid'],
            'time' => $time,
            'temperature' => $user['temperature'],
            'adress' => $user['adress'],
            'time1' => $now_date= date('Y-m-d',$time)
        ];
        $res = $demo->UpTemperature($user['userid'],$user['userMain'],$arr);
        return $res;
    }
//    用户长传接口 硬件端
    public function upTemperatureYj(){
        return '如果收到此消息说明访问成功';
    }
//    分页查询用户温度
    public function getTemperature(){
        $userid = $this->request->param('userid');
        $token = $this->request->param('userMain');
        $page = $this->request->param('page');
        $demo = new TemperatureDemo();
        $res = $demo->GetTemperature($userid,$token,$page);
        return $res;
    }
//    查询温度计是否被绑定
    public function ifBinded(){
        $macId = $this->request->param('macId');
        $demo = new TemperatureDemo();
        $res = $demo -> IfBinded($macId);
        return $res;
    }
}