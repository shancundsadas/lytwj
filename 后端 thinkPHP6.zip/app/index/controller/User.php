<?php

namespace app\index\controller;
use app\BaseController;
use app\index\business\user\UserDemo;

class User extends BaseController
{
//用户注册(ok)
    public function userRegister(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $userDemo = new UserDemo();
        $res = $userDemo->UserRegister($userid,$userkey);
        return $res;
    }

//    用户登录
    public function userLogin(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $userDemo = new UserDemo();
        $res = $userDemo->login($userid,$userkey);
        return $res;
    }

//用户信息填写
    public function upUserData(){
        //数据不可少
        $user = $this->request->param();
        $arr = [
            'name' => $user['name'],
            'userAdress'=>$user['userAdress'],
            'idNumber' => $user['idNumber'],
            'phone' => $user['phone'],
            'sex' => $user['sex'],
            'ifData' => 1
        ];
        $userDemo = new UserDemo();
        $res = $userDemo->makeData($user['userid'],$user['userMain'],$arr);
        return $res;
    }

//    用户与蓝牙之间绑定
    public function upUserBind(){
        //数据不可少
        $macId = $this->request->param();
        $arr = [
            'ifBind' => $macId['ifBind']
        ];
        $userDemo = new UserDemo();
        $res = $userDemo->makeData($macId['userid'],$macId['userMain'],$arr);
        return $res;
    }

//    检测用户是否绑定蓝牙信息
    public  function ifDataBind(){
//        检测信息是否编写 蓝牙是否绑定
        $userid = $this->request->param('userid');
        $token = $this->request->param('userMain');
        $userDemo = new UserDemo();
        $res = $userDemo->dataBind($userid,$token);
        return $res;
    }

//    获取我的信息
    public  function getMyData(){
//        检测信息是否编写 蓝牙是否绑定
        $userid = $this->request->param('userid');
        $token = $this->request->param('userMain');
        $userDemo = new UserDemo();
        $res = $userDemo->GetMyData($userid,$token);
        return $res;
    }
}