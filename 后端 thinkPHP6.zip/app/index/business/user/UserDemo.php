<?php

namespace app\index\business\user;

use app\common\common;
use app\index\CommonFun;
use app\index\model\user\UserDataModel;
use app\index\model\user\UserModel;

class UserDemo extends common
{
//用户注册demo
    public function UserRegister($userid,$userkey){
        $user = new UserModel();
        $userData = new UserDataModel();
        $com = new common();
        $results = $user->getUserId($userid);
        if(empty($results)){
            //可注册
            //生成三个两位随机数
            $key0 = $com->GetRandStr(2);
            $key1 = $com->GetRandStr(2);
            $key2 = $com->GetRandStr(2);
            //生成特定的 密钥  顺序 2 0 1
            $secret = $key2.$key0.$key1;
//        注册用户产生的密钥
            $userkey = md5($key0.$userid.$key1.$userkey.$key2);
            $res = $user->saveUser($userid,$userkey,$secret);
            if($res){
                //注册成功 自动生成用户信息
                $res = $userData -> addUserData([
                    'user_id'=>$userid,
                ]);
                if($res){
                    return $com->show(1,'',['res'=>'注册成功！']);
                }return $com->show(0,'',['res'=>'用户信息录入失败，请联系管理员！']);
            }
            return $com->show(0,'',['res'=>'注册失败请重试！']);;
        }else{
            //已经被注册
            return $com->show(0,'',['res'=>'用户已经被注册！']);
        }

    }

    //用户登录
    public function login($userid,$userkey){
        $userif = new CommonFun();
        $res = $userif->UserIf($userid,$userkey);
        if($res == 0){
            return $this->show(0,'',['res'=>'还没有创建账户']) ;
        }elseif ($res == 1){
            //验证成功 返回用户数据
            $userData = new UserDataModel();
            $res = $userData->getSomeUserData($userid);
            $token = $userif->makeToken($userid,$userkey);
//            $res = array_combine($res,["token" => $token]);
            return $this->show(1,'',['res'=>$res,'userMain'=>$token]);
        }elseif ($res == 2){
            return $this->show(0,'',['res'=>'密码错误']) ;
        }
    }
//
//修改用户基本信息
    public function makeData($userid,$token,$arr){
        $userif = new CommonFun();
        $res = $userif->UserToken($userid,$token);
        if(!$res){
            return $this->show(0,'',['res'=>'验证错误']) ;
        }else{
            $up = new UserDataModel();
            $res = $up->upUserData($userid,$arr);
            if($res){
                return $this->show(1,'',['res'=>'修改成功！']);
            }return $this->show(0,'',['res'=>'修改失败！']);
        }
    }
//    检测用户是否已经绑定
    public function dataBind($userid,$token){
        $userif = new CommonFun();
        $res = $userif->UserToken($userid,$token);
        if(!$res){
            return $this->show(0,'',['res'=>'验证错误']) ;
        }else{
            //验证成功 返回用户数据
            $userData = new UserDataModel();
            $res = $userData->getSomeUserData($userid);
            return $this->show(1,'',['res'=>$res]);
        }
    }

//    获取用户的信息
    public function GetMyData($userid,$token){
        $userif = new CommonFun();
        $res = $userif->UserToken($userid,$token);
        if(!$res){
            return $this->show(0,'',['res'=>'验证错误']) ;
        }else{
            //验证成功 返回用户数据
            $userData = new UserDataModel();
            $res = $userData->getSomeUserData($userid);
            return $this->show(1,'',['res'=>$res]);
        }
    }
}