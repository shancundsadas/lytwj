<?php

namespace app\index\business\temperature;

use app\common\common;
use app\index\model\user\UserDataModel;
use app\index\CommonFun;
use app\index\model\temperature\TemperatureModel;


class TemperatureDemo extends common
{
//    上传温度 软件端
    public function UpTemperature($userid,$token,$arr){
//        首先进行token验证
        $userif = new CommonFun();
        $res = $userif->UserToken($userid,$token);
        if($res == 0){
            return $this->show(0,'',['res'=>'验证失败']) ;
        }elseif ($res == 1){
            //验证成功 返回用户数据
            $userData = new TemperatureModel();
            $res = $userData->addTemperatureDemo($arr);
            if($res){
//                上传成功  根据操作修改是否上传
                $demo = new UserDataModel();
                $demo = $demo -> todayCw($userid,$arr['temperature']);
                if($demo){
                    return $this->show(1,'',['res'=>'上传成功']);
                }
                return $this->show(1,'',['res'=>'上传失败']);
            }
            return $this->show(0,'',['res'=>'上传失败']);
        }
    }

//    获取用户上传的温度 分页查询
    public function GetTemperature($userid,$token,$page){
        //首先进行token验证
        $userif = new CommonFun();
        $res = $userif->UserToken($userid,$token);
        if($res == 0){
            return $this->show(0,'',['res'=>'验证失败']) ;
        }elseif ($res == 1){
            //验证成功 返回用户数据
            $userData = new TemperatureModel();
            $res = $userData->getTimestamp($userid,$page);
            if($res){
                return $this->show(1,'',['res'=>$res]);
            }
            return $this->show(0,'',['res'=>'获取失败']);
        }
    }
//    检查是否已经被绑定
    public function IfBinded($macId){
        //首先进行token验证
            //验证成功 返回用户数据
            $userData = new UserDataModel();
            $res = $userData->getBinded($macId);
            if($res == '[]'){
                return $this->show(1,'',['res'=>'没有被绑定']);
            }return $this->show(0,'',['res'=>'已经被绑定']);
    }
}