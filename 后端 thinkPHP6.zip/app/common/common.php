<?php

namespace app\common;

class common
{
    //生成随机字符数
    public function GetRandStr($length){
        //字符组合
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $len = strlen($str)-1;
        $randstr = '';
        for ($i=0;$i<$length;$i++) {
            $num=mt_rand(0,$len);
            $randstr .= $str[$num];
        }
        return $randstr;
    }

    //封装json返回格式
    //$status   业务代码
    //$message  返回消息
    //$data     返回数据
    //$httpStatus  HTTP状态码
    function show($status, $message = 'error', $data = [], $httpStatus = 200)
    {
        $result = [
            "status" => $status,
            "message" => $message,
            "result" => $data
        ];
        return json($result, $httpStatus);
    }


}