<?php

namespace app\ogjdhc\controller;
use app\BaseController;
use app\index\model\temperature\TemperatureModel;
use app\index\model\user\UserDataModel;
use app\ogjdhc\business\admintemperature\AdminTemperature;

class Temperature extends BaseController
{
//    返回温度总也表
    public function getAllTemperature(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $page = $this->request->param('page');
        $res = new AdminTemperature();
        return $res -> GetAllTemperature($userid,$userkey,$page);
    }
//    返回今日的时间表
    public function getAllTemperatureToday(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $page = $this->request->param('page');
        $res = new AdminTemperature();
        return $res -> GetAllTemperatureToday($userid,$userkey,$page);
    }
//查询今日体温异常
    public function getTemNo(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $page = $this->request->param('page');
        $res = new AdminTemperature();
        return $res -> GetTemNo($userid,$userkey,$page);
    }
    //    查询用户的详细信息
    public function getOneTemperature(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $getuser = $this->request->param('getuser');
        $page = $this->request->param('page');
        $res = new AdminTemperature();
        return $res -> GetOneTemperature($userid,$userkey,$getuser,$page);
    }
}