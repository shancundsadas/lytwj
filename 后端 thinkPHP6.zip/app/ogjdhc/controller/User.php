<?php

namespace app\ogjdhc\controller;

use app\BaseController;
use app\ogjdhc\business\user\AdminDemo;

class User extends BaseController
{
//    获取全部用户名称
    public function getAllUser(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $page = $this->request->param('page');
        $data = new AdminDemo();
        return $data -> GetAllUserData($userid,$userkey,$page);
    }

    //    用户添加
    public function upUser(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $getid = $this->request->param('getUser');
        $getkey = $this->request->param('getkey');
        $data = new AdminDemo();
        return $data -> AppUser($userid,$userkey,$getid,$getkey);
    }

//    用户信息修改
    public function changeUser(){
        $user = $this->request->param();
        $arr = [
            'name' => $user['name'],
            'userAdress'=>$user['userAdress'],
            'idNumber' => $user['idNumber'],
            'phone' => $user['phone'],
            'sex' => $user['sex'],
            'ifData' => 1
        ];
        $data = new AdminDemo();
        return $data -> ChanegUser($user['userid'],$user['userkey'],$user['getuser'],$arr);
    }

//    查询用户信息详情
    public function getUserData(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $getUser = $this->request->param('getuser');
        $data = new AdminDemo();
        return $data -> GetOneUser($userid,$userkey,$getUser);
    }

//    清空用户信息
    public function delUserData(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $getUser = $this->request->param('getuser');
        $data = new AdminDemo();
        return $data -> DelUser($userid,$userkey,$getUser);
    }
}