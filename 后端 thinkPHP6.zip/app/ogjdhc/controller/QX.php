<?php

namespace app\ogjdhc\controller;

use app\BaseController;
use app\ogjdhc\business\admin\Admin;

class QX extends BaseController
{

//管理员登录
    public function adminLogin(){
//        AdminLogin
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $res = new Admin();
        return $res -> AdminLogin($userid,$userkey);
    }
    public function index(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $getuser = $this->request->param('getUser');
        $str = $this->request->param('str');
        $res = new Admin();
        return $res -> MakeVerification($userid,$userkey,$getuser,$str);
    }

    public function searchqx(){
        $userid = $this->request->param('userid');
        $userkey = $this->request->param('userkey');
        $res = new Admin();
        return $res -> searchQx($userid,$userkey);
    }
}