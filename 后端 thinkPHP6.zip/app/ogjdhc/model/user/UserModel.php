<?php

namespace app\ogjdhc\model\user;

use think\Model;

class UserModel extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'zxcw_user';
//    获取用户权限信息
    public function getVerificationStr($userid){
        return $this->where('user_id',$userid)->field('verification')->select();
    }
//检查是否有登陆权限
    public function getJurisdiction($userid){
        return $this->where('user_id',$userid)->field('jurisdiction')->find();
    }
//用户信息删除
    public function delUser($userid)
    {
        return $this->where('user_id', $userid)->delete();
    }
//    权限分配上传
    public function makeVerification($userid,$str)
    {
        return $this->where('user_id', $userid)->update(['verification' => $str]);
    }
//    等级上传
    public function makeJurisdiction($userid,$dj)
    {
        return $this->where('user_id', $userid)->update(['jurisdiction' => $dj]);
    }
}