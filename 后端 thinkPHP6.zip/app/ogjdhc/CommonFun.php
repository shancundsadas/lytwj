<?php

namespace app\ogjdhc;
//处理用户token
use app\ogjdhc\model\user\UserModel;

class CommonFun
{
//    登陆管理员检查
    public function adminLogin($userid,$userkey){
        $res = new \app\index\CommonFun();
        $res = $res->UserIf($userid,$userkey);
//        echo $res.'用户登录成功吗？';
//        用户账号登陆成功 检测是否有权限
        if($res == 1){
            $data = new UserModel();
            $res = $data->getJurisdiction($userid);
            if($res['jurisdiction'] > 0){
//                echo '通过第一个！';
                return 1;
            }
            return 0;
        }
        return 0;
    }
//    权限验证 用户ID  权限需求$v
    public function verification($userid,$userkey,$v){
        $res = $this->adminLogin($userid,$userkey);
//        echo $userid.$userkey.'获取账号密码';
//        登录验证成功
        if($res == 1){
            $str = new UserModel();
            $str = $str->getVerificationStr($userid);
//            echo '这里的数据拿出来了'.$str[0]['verification'].'   ';
            if($str == ''){
                return 0;
            }else{
//            用户所有的权限数组
                $arr = explode(",",$str[0]['verification']);
//                print_r($arr);
                foreach ($arr as &$val){  // 遍历数组
                    if($val == $v){
                        return 1;
                    }
                }
                return 0;
            }
        }

    }


}