<?php

namespace app\ogjdhc\business\user;

use app\common\common;
use app\index\business\user\UserDemo;
use app\index\model\temperature\TemperatureModel;
use app\index\model\user\UserDataModel;
//use app\index\model\user\UserModel;
use app\ogjdhc\CommonFun;
use app\ogjdhc\model\user\UserModel;

class AdminDemo extends common
{
//    获取全部用户信息 分页查询
    public function GetAllUserData($userid,$userkey,$page){
//        登陆检查 是否为管理账号
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'h');
        if($res == 1){
//            验证权限成功
            $data = new UserDataModel();
            $res = $data-> getAllData($page);
            if($res){
                return $this->show(1,'',['res'=>$res]);
            }
            return $this->show(0,'',['res'=>'查询失败']);
        }
        return $this->show(0,'',['res'=>'权限不足']);
    }

//    用户增加
    public function AppUser($userid,$userkey,$getid,$getkey){
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'a');
        if($res == 1){
//            验证权限成功
            $demo = new UserDemo();
            $demo = $demo -> UserRegister($getid,$getkey);
            return $demo;
        }
        return $this->show(0,'',['res'=>'权限审核未通过']);;
    }

//    用户信息修改
    public function ChanegUser($userid,$userkey,$getuser,$arr){
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'b');
        if($res == 1){
//            验证权限成功
            $up = new UserDataModel();
            $res = $up->upUserData($getuser,$arr);
            if($res){
                return $this->show(1,'',['res'=>'修改成功！']);
            }
            return $this->show(0,'',['res'=>'修改失败，请重试！']);
        }
        return $this->show(0,'',['res'=>'权限审核未通过']);;
    }

    //    用户信息查询  $userid $userkey 管理员账号密码   $getUser需要查询的账号
    public function GetOneUser($userid,$userkey,$getUser){
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'c');
        if($res == 1){
//            验证权限成功
            $userData = new UserDataModel();
            $res = $userData->getSomeUserData($getUser);
            if($res){
                return $this->show(1,'',['res'=>$res]);
            }
            return $this->show(1,'',['res'=>'数据为空']);
        }
        return $this->show(0,'',['res'=>'权限审核未通过']);;
    }

//    删除用户  通过ID删除用户
    public function DelUser($userid,$userkey,$getUser){
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'d');
//        echo $res;
        if($res == 1){
//            echo $res;
//            验证权限成功
            $userData = new UserDataModel();
            $user = new UserModel();
            $te = new TemperatureModel();
            $userData = $userData -> delUserData($getUser);
            echo '这是用户信息清除'.$userData;
            $user = $user-> delUser($getUser);
            echo '这是用户清除'.$user;
            $te = $te -> delUserTem($getUser);
            echo '这是用户体温信息清除'.$te;
            return $this->show(1,'',['res'=>'清楚用户信息成功']);
        }
        return $this->show(0,'',['res'=>'权限审核未通过']);;
    }
}