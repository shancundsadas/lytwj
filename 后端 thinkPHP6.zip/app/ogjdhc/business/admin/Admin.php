<?php

namespace app\ogjdhc\business\admin;

use app\common\common;
use app\index\model\temperature\TemperatureModel;
use app\index\model\user\UserDataModel;
use app\ogjdhc\model\user\UserModel;
use app\ogjdhc\CommonFun;

class Admin extends common
{
//    权限分配功能
    public function MakeVerification($userid,$userkey,$getuser,$str){
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'g');
        if($res == 1){
//            获得权限分配功能
//            判断用户等级 只能给 低等级用户

            $res = new UserModel();
            $res0 = $res -> getJurisdiction($userid);//第一用户
            $res1 = $res -> getJurisdiction($getuser);//获取权限用户
//            echo $res0['jurisdiction'];
//            上一级用户更大  获取分配权力
            if($res0['jurisdiction'] > $res1['jurisdiction']){
//                修改权限
                $res4 = $res -> makeJurisdiction($getuser,$res0['jurisdiction']-1);
//                获取第一用户拥有的权力 职能分配可以分配的
                $res3 = $res -> getVerificationStr($userid);
                $arr0 = explode(",",$str); //短的
                $arr1 = explode(",",$res3[0]['verification']);
                foreach ($arr0 as &$value){
                    if(in_array($value,$arr1)){
//                        新上传数组的权限在这里面都找得到
                    }else{
                        return $this->show(0,'',['res'=>'抱歉，您没有权限！']);
                    }
                }
//                对比 用户权限
                $res3 = $res -> makeVerification($getuser,$str);
                if($res3){
                    return $this->show(1,'',['res'=>'权限分配成功']);
                }
                return $this->show(0,'',['res'=>'获取失败']);
            }
        }
        return $this->show(0,'',['res'=>'验证失败']);
    }

//    权限查询功能 查询用户权限
    public function searchQx($userid,$userkey){
        $res = new CommonFun();
        $res1 = $res->verification($userid,$userkey,'g');
        if($res1 == 1){
            $res0 = new UserModel();
            $res2 = $res0 -> getVerificationStr($userid);
            return $this->show(1,'',['res'=>$res2]);
        }return $this->show(0,'',['res'=>'验证失败']);
    }

//    管理员登录
    public function AdminLogin($userid,$userkey){
        $userif = new \app\index\CommonFun();
        $res = $userif->UserIf($userid,$userkey);
        if($res == 0){
            return $this->show(0,'',['res'=>'']) ;
        }elseif ($res == 1){
            //验证成功 返回用户数据
//            判断是否为管理员
            $demo = new UserModel();
            $res = $demo->getJurisdiction($userid);
            if($res['jurisdiction'] > 0){
                return $this->show(1,'',['res'=>'登陆成功']);
            }
            return $this->show(0,'',['res'=>'']) ;
        }elseif ($res == 2){
            return $this->show(0,'',['res'=>'']) ;
        }
    }
}