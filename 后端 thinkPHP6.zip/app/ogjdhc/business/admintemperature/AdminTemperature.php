<?php

namespace app\ogjdhc\business\admintemperature;

use app\common\common;
use app\index\model\temperature\TemperatureModel;
use app\ogjdhc\CommonFun;

class AdminTemperature extends common
{
//    查询温度总表格
    public function GetAllTemperature($userid,$userkey,$page){
//        查询全部数据表数据
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'e');
        if($res == 1){
            $data = new TemperatureModel();
            $data = $data->getAllTimestamp($page);
            if($data){
                return $this->show(1,'',['res'=>$data]);
            }
            return $this->show(0,'',['res'=>'获取失败']);
        }
        return $this->show(0,'',['res'=>'验证失败']);
    }
//    查询当天的温度总表
    public function GetAllTemperatureToday($userid,$userkey,$page){
//        查询全部数据表数据
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'e');
        if($res == 1){
            $data = new TemperatureModel();
            $data = $data->getAllTimestampTy($page);
            if($data){
                return $this->show(1,'',['res'=>$data]);
            }
            return $this->show(0,'',['res'=>'获取失败']);
        }
        return $this->show(0,'',['res'=>'验证失败']);
    }
// 查询今日体温异常 GetTemNo
    public function GetTemNo($userid,$userkey,$page){
//        查询全部数据表数据
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'e');
        if($res == 1){
            $data = new TemperatureModel();
            $data = $data->getTemNote($page);
            if($data){
                return $this->show(1,'',['res'=>$data]);
            }
            return $this->show(0,'',['res'=>'获取失败']);
        }
        return $this->show(0,'',['res'=>'验证失败']);
    }
//     查询用户的详细信息
    public function GetOneTemperature($userid,$userkey,$getid,$page){
//        查询全部数据表数据
        $res = new CommonFun();
        $res = $res->verification($userid,$userkey,'f');
        if($res == 1){
            $data = new TemperatureModel();
            $data = $data->getTimestamp($getid,$page);
            if($data){
                return $this->show(1,'',['res'=>$data]);
            }
            return $this->show(0,'',['res'=>'获取失败']);
        }
        return $this->show(0,'',['res'=>'验证失败']);
    }
}