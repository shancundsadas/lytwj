<?php
use think\facade\Route;
//http://159.75.138.69:9651/public/index.php/ogjdhc
//获取全部用户信息   userid userkey page
Route::post('getAllUser','controller/User/getAllUser')->allowCrossDomain();

//用户添加 userid  userkey  getUser  getkey
Route::post('upUser','controller/User/upUser')->allowCrossDomain();

//用户信息修改 userid  userkey getuser name userAdress idNumber phone sex
Route::post('changeUser','controller/User/changeUser')->allowCrossDomain();

//查询用户信息详情  userid  userkey  getuser
Route::post('getUserData','controller/User/getUserData')->allowCrossDomain();

//清空用户信息  userid  userkey getuser
Route::post('delUserData','controller/User/delUserData')->allowCrossDomain();

//返回温度表 userid  userkey  page
Route::post('getAllTemperature','controller/Temperature/getAllTemperature')->allowCrossDomain();

//返回今日温度表 userid  userkey  page
Route::post('getAllTemperatureToday','controller/Temperature/getAllTemperatureToday')->allowCrossDomain();

//返回今日温度异常温度表 userid  userkey  page
Route::post('getTemNo','controller/Temperature/getTemNo')->allowCrossDomain();

//查询用户的温度信息表   userid  userkey  getuser  page
Route::post('getOneTemperature','controller/Temperature/getOneTemperature')->allowCrossDomain();

//设置用户权限   userid  userkey  getuser  str
Route::post('QX','controller/QX/index')->allowCrossDomain();

//管理员登录   userid  userkey
Route::post('adminLogin','controller/QX/adminLogin')->allowCrossDomain();

//查询权限   userid  userkey
Route::post('searchqx','controller/QX/searchqx')->allowCrossDomain();
